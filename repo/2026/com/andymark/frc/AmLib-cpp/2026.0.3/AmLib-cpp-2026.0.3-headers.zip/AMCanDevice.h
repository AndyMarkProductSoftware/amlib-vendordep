/**
 * @file AMCanDevice.h
 * @brief Base class for AndyMark CAN devices on the FRC roboRIO CAN bus.
 * @details Wraps WPILib's frc::CAN to provide a common transport, message helpers, and device identity.
 *
 * @copyright
 *   (c) AndyMark. All rights reserved.
 */

#pragma once

#include <frc/CAN.h>
#include "AMCanDevice_Constants.h"
#include <chrono>
#include <thread>

/**
 * @class CanDevice
 * @brief Common base abstraction for AndyMark CAN devices.
 * @details Construct with a device ID, manufacturer, and device type. Provides protected helpers to send/receive raw CAN packets and public utility methods.

 */
class CanDevice {
public:
    /**
 * @brief Construct a CAN device wrapper.
 * @param deviceID The 6-bit/8-bit device ID on the CAN bus.
 * @param deviceManufacturer 8-bit manufacturer code (e.g., 15 for AndyMark).
 * @param deviceType Device type identifier (matches on-device firmware).
 */
explicit CanDevice(int deviceID, int deviceManufacturer, int deviceType);
    /**
 * @brief Virtual destructor.
 * @details Necessary for correct cleanup through base pointers.
 */
virtual ~CanDevice() = default;
    
    /**
 * @brief Get this device's configured CAN ID.
 * @return The numeric CAN device ID.
 */
int getDeviceId();
    
    /**
 * @brief Request a device reboot via CAN command.
 * @details Sends a vendor-specific API frame defined by RESTART_DEVICE_API.
 */
void RestartDevice();
    



protected:
    /** Underlying WPILib CAN endpoint. */
frc::CAN m_can;
    /** Configured CAN device ID. */
int m_deviceID;
    /** Manufacturer code (8-bit). */
int deviceManufacturer;
    /** Device type identifier. */
int deviceType;

    /**
 * @brief Low-level helper to transmit a CAN packet.
 * @param apiID Vendor-specific API ID used to route the message.
 * @param data Pointer to payload bytes (may be nullptr when length==0).
 * @param length Number of payload bytes (0..8).
 */
void SendCANMessage(int apiID, const uint8_t* data, int length);
    /**
 * @brief Receive a packet with a specific API ID, optionally waiting up to timeout.
 * @details Wraps WPILib frc::CAN::ReadPacketTimeout.
 * @param apiID Expected API ID to match.
 * @param frc::CANData* Destination structure for received data.
 * @param timeoutMs Maximum time to wait for a packet (milliseconds).
 * @return True if a matching frame was received within the timeout; false otherwise.
 */
bool ReceiveCANMessage(int apiID, frc::CANData*, int timeoutMs);
};
