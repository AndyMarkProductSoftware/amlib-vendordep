/**
 * @file AM_CAN_Koors40.h
 * @brief Motor controller API for the Koors40 device.
 * @details Provides setpoints and mode controls (brake/coast) over CAN.
 *
 * @copyright
 *   (c) AndyMark. All rights reserved.
 */

#pragma once

#include "AMCanDevice.h"
#include "AMCanDevice_Constants.h"

/**
 * @class CAN_Koors40
 * @brief Motor controller device (Koors40).
 * @details 

 */
class CAN_Koors40 : public CanDevice {
public:
    /**
 * @brief Construct a Koors40 device with the given CAN ID.
 * @param deviceID The device's CAN ID.
 */
explicit CAN_Koors40(int deviceID);
    
    /**
 * @brief Command the motor with a percentage output.
 * @param speed Desired output in percent [-100..100]. Values are clamped.
 */
void setSpeed(int speed);
    /**
 * @brief Put the controller in brake (coast disabled) mode.
 */
void setBrakeMode();
    /**
 * @brief Put the controller in coast (brake disabled) mode.
 */
void setCoastMode();



private:

protected:
    
};