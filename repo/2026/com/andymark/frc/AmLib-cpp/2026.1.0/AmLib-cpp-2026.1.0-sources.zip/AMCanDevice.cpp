#include "AMCanDevice.h"
#include <iostream>
#include "AMDiagnosticsServer.h"

CanDevice::CanDevice(int deviceID, int deviceManufacturer, int deviceType)
    : m_can(deviceID, deviceManufacturer,deviceType), m_deviceID(deviceID), 
      deviceManufacturer(deviceManufacturer), deviceType(deviceType) {
                
        andymark::diag::EnsureServerRunning();  // starts server on first device

        //std::cout << "Initialized Device" << std::endl;
    }

void CanDevice::SendCANMessage(int apiID, const uint8_t* data, int length) {
    try
    {
            m_can.WritePacket(data, length, apiID);
    }
    catch(const std::exception&)
    {
        return;
    }
}

bool CanDevice::ReceiveCANMessage(int apiID, frc::CANData* data,int timeoutMs) {

    return m_can.ReadPacketTimeout(apiID, timeoutMs, data);
       
    }

void CanDevice::RestartDevice(){
    SendCANMessage(RESTART_DEVICE_API,NULL,0);
}

int CanDevice::getDeviceId(){
    return m_deviceID;
}