#include "AM_CAN_Mag_Switch.h"

AM_CAN_Mag_Switch::AM_CAN_Mag_Switch(int deviceID)
    : CanDevice(deviceID, 15, 10) // 15 = AndyMark vendor, 10 = Miscellaneous device type
{
    data.magnetDetected = false;
    data.timeStamp = 0;
}

uint32_t AM_CAN_Mag_Switch::ParseTimestampLE(const uint8_t* b)
{
    // b points to data[1] (LSB first)
    return (static_cast<uint32_t>(b[3]) << 24) |
           (static_cast<uint32_t>(b[2]) << 16) |
           (static_cast<uint32_t>(b[1]) << 8)  |
           (static_cast<uint32_t>(b[0]));
}

AM_MagSwitchData AM_CAN_Mag_Switch::GetData()
{
    return GetData(150);
}

AM_MagSwitchData AM_CAN_Mag_Switch::GetData(int timeoutMs)
{
    frc::CANData hallFrame;

    if (ReceiveCANMessage(HALL_EFFECT_DATA, &hallFrame, timeoutMs))
    {
        // data[0] = magnetDetected (1/0)
        data.magnetDetected = (hallFrame.data[0] != 0);

        // data[1..4] = timestamp LE
        data.timeStamp = ParseTimestampLE(&hallFrame.data[1]);
    }

    return data;
}

bool AM_CAN_Mag_Switch::SetReportPeriod(int periodMs)
{
    // Clamp to uint16 just like Java version
    if (periodMs < 0) periodMs = 0;
    if (periodMs > 0xFFFF) periodMs = 0xFFFF;

    uint8_t payload[2] = {
        static_cast<uint8_t>(periodMs & 0xFF),
        static_cast<uint8_t>((periodMs >> 8) & 0xFF)
    };

    SendCANMessage(SET_REPORT_PERIOD_API, payload, 2);
    return true;
}

bool AM_CAN_Mag_Switch::ResetReportPeriod()
{
    uint8_t dummy[1] = {0};
    SendCANMessage(RESET_REPORT_PERIOD_API, dummy, 0);
    return true;
}
