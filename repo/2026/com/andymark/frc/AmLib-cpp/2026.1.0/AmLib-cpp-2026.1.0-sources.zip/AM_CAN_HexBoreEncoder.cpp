#include "AM_CAN_HexBoreEncoder.h"
#define _USE_MATH_DEFINES
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif


/* Base transport comes from CanDevice:
 *  - SendCANMessage(api, data, len)
 *  - ReceiveCANMessage(api, &CANData, timeout)
 * See color sensor for the same usage pattern. */

AM_CAN_HexBoreEncoder::AM_CAN_HexBoreEncoder(int deviceID)
: CanDevice(deviceID, 15, 7) {
    // Initialize caches to zeros.
    m_telem = {};
    m_status = {};
}

AM_EncoderTelemetry AM_CAN_HexBoreEncoder::GetTelemetry(int timeoutMs) {
    frc::CANData frame{};
    if (ReceiveCANMessage(ENCODER_TELEMETRY_DATA, &frame, timeoutMs)) {
        // Expect exactly 8 bytes
        if (frame.length >= 8) {
            m_telem.angle_zeroed_counts   = rd_u16le(&frame.data[0]);
            m_telem.velocity_counts_per_s = rd_i16le(&frame.data[2]);
            m_telem.magnitude             = rd_u16le(&frame.data[4]);
            m_telem.diag_err              = frame.data[6];
            m_telem.seq                   = frame.data[7];
        }
    }
    return m_telem;
}

AM_EncoderStatus AM_CAN_HexBoreEncoder::GetStatus(int timeoutMs) {
    frc::CANData frame{};
    if (ReceiveCANMessage(ENCODER_STATUS_DATA, &frame, timeoutMs)) {
        if (frame.length >= 8) {
            m_status.angle_offset_cd = rd_u16le(&frame.data[0]);
            m_status.agc             = frame.data[2];
            m_status.diag_misc       = frame.data[3];
            m_status.raw_angle_comp  = rd_u16le(&frame.data[4]);
            m_status.errfl           = rd_u16le(&frame.data[6]);
        }
    }
    return m_status;
}

/* ---------------- Convenience conversions ---------------- */

double AM_CAN_HexBoreEncoder::GetAngleDegrees() const {
    return (static_cast<double>(m_telem.angle_zeroed_counts & 0x3FFF) * (360.0 / kCountsPerRev));
}

double AM_CAN_HexBoreEncoder::GetAngleRadians() const {
    return GetAngleDegrees() * (M_PI / 180.0);
}

double AM_CAN_HexBoreEncoder::GetVelocityDegPerSec() const {
    return static_cast<double>(m_telem.velocity_counts_per_s) * (360.0 / kCountsPerRev);
}

double AM_CAN_HexBoreEncoder::GetVelocityRadPerSec() const {
    return GetVelocityDegPerSec() * (M_PI / 180.0);
}

/* ---------------- Commands ---------------- */

void AM_CAN_HexBoreEncoder::SetZeroHere() {
    SendCANMessage(ENCODER_ZERO_CURRENT_POS, nullptr, 0);
}

void AM_CAN_HexBoreEncoder::ResetOffset() {
    SendCANMessage(ENCODER_RESET_OFFSET, nullptr, 0);
}

void AM_CAN_HexBoreEncoder::SetOffsetDegrees(double degrees) {
    // Convert to centi-degrees, normalize 360.00 -> 0
    int32_t cd = static_cast<int32_t>(std::lround(degrees * 100.0));
    // Normalize into [0, 36000)
    cd %= 36000; if (cd < 0) cd += 36000;
    uint16_t payload = static_cast<uint16_t>(cd == 36000 ? 0 : cd);

    uint8_t data[2] = {
        static_cast<uint8_t>(payload & 0xFF),
        static_cast<uint8_t>((payload >> 8) & 0xFF)
    };
    SendCANMessage(ENCODER_SET_OFFSET, data, 2);
}

void AM_CAN_HexBoreEncoder::SetReportPeriod(int periodMs) {
    uint16_t p = static_cast<uint16_t>(periodMs);
    uint8_t data[2] = {
        static_cast<uint8_t>(p & 0xFF),
        static_cast<uint8_t>((p >> 8) & 0xFF)
    };
    SendCANMessage(SET_REPORT_PERIOD_API, data, 2);
}

void AM_CAN_HexBoreEncoder::ResetReportPeriod() {
    SendCANMessage(RESET_REPORT_PERIOD_API, nullptr, 0);
}
