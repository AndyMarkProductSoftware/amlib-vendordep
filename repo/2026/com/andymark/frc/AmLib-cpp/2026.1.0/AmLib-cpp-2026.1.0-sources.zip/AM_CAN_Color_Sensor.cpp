#include "AM_CAN_Color_Sensor.h"
AM_CANColorSensor::AM_CANColorSensor(int deviceID)
    : CanDevice(deviceID,15,13) {
        data.blue=0;
        data.clearC=0;
        data.green=0;
        data.millisStamp=0;
        data.proximity=0;
        data.red=0;
    } //15 is AndyMark vendor ID, 7 is gear tooth sensor device type




AM_ColorSensorData AM_CANColorSensor::GetData(){
    frc::CANData colorData, proximityAndTimestamp;

    if(ReceiveCANMessage(COLORSENSOR_COLORDATA_API, &colorData,150))
    {
        data.clearC = (uint16_t)colorData.data[1] << 8 | colorData.data[0];
        data.red = (uint16_t)colorData.data[3] << 8 | colorData.data[2];
        data.green = (uint16_t)colorData.data[5] << 8 | colorData.data[4];
        data.blue = (uint16_t)colorData.data[7] << 8 | colorData.data[6];

        
    }
    

    if(ReceiveCANMessage(COLORSENSOR_PROX_TIMESTAMP_API, &proximityAndTimestamp,150))
    {
        data.proximity = (uint8_t)proximityAndTimestamp.data[0];
        data.millisStamp = (uint32_t) proximityAndTimestamp.data[4] << 24 | proximityAndTimestamp.data[3] << 16 | proximityAndTimestamp.data[2] << 8 | proximityAndTimestamp.data[1];
    }
    

    return data;
}

AM_ColorSensorData AM_CANColorSensor::GetData(int timeoutMs){
    frc::CANData colorData, proximityAndTimestamp;

    AM_ColorSensorData data;

    if(ReceiveCANMessage(COLORSENSOR_COLORDATA_API, &colorData,timeoutMs))
    {
        data.clearC = (uint16_t)colorData.data[1] << 8 | colorData.data[0];
        data.red = (uint16_t)colorData.data[3] << 8 | colorData.data[2];
        data.green = (uint16_t)colorData.data[5] << 8 | colorData.data[4];
        data.blue = (uint16_t)colorData.data[7] << 8 | colorData.data[6];
    }
    

    if(ReceiveCANMessage(COLORSENSOR_PROX_TIMESTAMP_API, &proximityAndTimestamp,timeoutMs))
    {
        data.proximity = (uint8_t)proximityAndTimestamp.data[0];
        data.millisStamp = (uint32_t) proximityAndTimestamp.data[4] << 24 | proximityAndTimestamp.data[3] << 16 | proximityAndTimestamp.data[2] << 8 | proximityAndTimestamp.data[1];
    }
    
    return data;
}


bool AM_CANColorSensor::SetReportPeriod(int periodMs) {
    // LSB first, MSB second (little-endian)
    uint8_t data[2] = {
        static_cast<uint8_t>(periodMs & 0xFF),
        static_cast<uint8_t>((periodMs >> 8) & 0xFF)
    };
    SendCANMessage(SET_REPORT_PERIOD_API, data, 2);
    return true; // or return the result of SendCANMessage if it returns a bool
}


bool AM_CANColorSensor::ResetReportPeriod()
{
    uint8_t data[1] = {0};
    SendCANMessage(RESET_REPORT_PERIOD_API, data, 0);
    return true;
}

bool AM_CANColorSensor::TurnLedOn()
{
    uint8_t data[1] = {1};
    SendCANMessage(COLOR_LED_ON_OR_OFF, data, 1);
    return true;
}

bool AM_CANColorSensor::TurnLedOff()
{
    uint8_t data[1] = {0};
    SendCANMessage(COLOR_LED_ON_OR_OFF, data, 1);
    return true;
}




