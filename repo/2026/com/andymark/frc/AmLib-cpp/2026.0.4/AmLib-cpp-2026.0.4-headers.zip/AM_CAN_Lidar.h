/**
 * @file AM_CAN_Lidar.h
 * @brief Time-of-Flight (VL53L1X) lidar device over CAN.
 * @details Provides access to distance, status, flags, debug signal data,
 *          and timestamp over CAN.
 *
 * @copyright
 *   (c) AndyMark. All rights reserved.
 */

#pragma once

#include <cstdint>

#include "AMCanDevice.h"
#include "AMCanDevice_Constants.h"

/**
 * @def AM_LIDAR_DEFAULT_OFFSET_MM
 * @brief Default mechanical offset (mm) applied to all distance readings.
 * @details
 * This is the "built-in" offset that accounts for where the actual VL53L1X
 * sensing plane sits inside the product housing / PCB.
 *
 * Teams can add an additional runtime offset via SetUserOffsetMm().
 *
 * Positive offset increases the reported distance.
 * Negative offset decreases the reported distance.
 */
#ifndef AM_LIDAR_DEFAULT_OFFSET_MM
#define AM_LIDAR_DEFAULT_OFFSET_MM 0
#endif


/**
 * @enum AM_LidarDistanceMode
 * @brief VL53L1X distance mode selection.
 *
 * @details
 * This controls the sensor's internal ranging profile.
 */
enum class AM_LidarDistanceMode : uint8_t {
    kShort  = 0,
    kMedium = 1,
    kLong   = 2,
};

/**
 * @struct AM_LidarData
 * @brief Aggregated primary readings from the lidar sensor.
 *
 * @details
 * This structure represents the **main distance measurement frame**
 * transmitted by the device.
 *
 * Fields include:
 *  - distance measurement
 *  - device status
 *  - device flags
 *  - device timestamp
 */
struct AM_LidarData {

    /**
     * @brief Distance measurement in millimeters.
     *
     * @details
     * This value already includes both:
     *  - the built-in device offset
     *  - any user-defined offset applied via SetUserOffsetMm()
     */
    uint16_t distanceMm;

    /**
     * @brief Device-defined status byte.
     *
     * @details
     * Indicates measurement validity or sensor state.
     * Typical values may include:
     *  - 0 : measurement valid
     *  - 1 : timeout occurred
     *  - 2 : device initialization failure
     *  - other values correspond to /VL53L1X internal range status codes.
     */
    uint8_t status;

    /**
     * @brief Device-defined flags byte.
     *
     * @details
     * Bitfield providing additional diagnostic information about the measurement.
     * Teams typically do not need this for normal gameplay use,
     * but it can be useful for debugging sensor performance.
     */
    uint8_t flags;

    /**
     * @brief Timestamp of the measurement in milliseconds since device boot.
     */
    uint32_t millisStamp;
};

/**
 * @struct AM_LidarDebugData
 * @brief Additional diagnostic signal information from the lidar sensor.
 *
 * @details
 * This data is transmitted periodically using a debug CAN frame.
 * These values help diagnose sensor performance issues such as
 * low reflectivity targets, bright ambient lighting, or poor mounting angles.
 */
struct AM_LidarDebugData {

    /**
     * @brief Peak return signal strength.
     *
     * @details
     * Measured in **centi-MCPS** (0.01 Mega Counts Per Second).
     */
    uint16_t peakSignalCentiMcps;

    /**
     * @brief Ambient light level detected by the sensor.
     *
     * @details
     * Also measured in **centi-MCPS**.
     */
    uint16_t ambientCentiMcps;

    /**
     * @brief Timestamp of the diagnostic sample in milliseconds since device boot.
     */
    uint32_t millisStamp;

    /**
     * @brief Indicates whether a debug frame has been received yet.
     */
    bool valid;
};

/**
 * @class AM_CANLidar
 * @brief ToF/Lidar sensor device.
 *
 * @details
 * Retrieves distance, status, flags, timestamp, and optional debug signal data
 * from the device over CAN.
 *
 * Offsets:
 *  - A fixed default offset (AM_LIDAR_DEFAULT_OFFSET_MM) is always applied.
 *  - Teams can apply an additional runtime offset via SetUserOffsetMm().
 *  - Total applied offset = default + user.
 *
 * Positive offsets increase reported distance, negative offsets decrease it.
 */
class AM_CANLidar : public CanDevice {
public:

    /**
     * @brief Construct a CAN lidar sensor with the given CAN ID.
     * @param deviceID The device's CAN ID.
     */
    explicit AM_CANLidar(int deviceID);

    /**
     * @brief Fetch the most recent lidar reading using the default timeout.
     * @return A filled AM_LidarData struct.
     */
    AM_LidarData GetData();

    /**
     * @brief Fetch lidar reading with a custom timeout applied to the CAN read.
     * @param timeoutMs Timeout in milliseconds for the CAN read.
     * @return A filled AM_LidarData struct.
     */
    AM_LidarData GetData(int timeoutMs);

    /**
     * @brief Retrieve the latest debug information from the sensor.
     *
     * @details
     * Attempts to read a debug CAN frame. If a new frame is not
     * available within the timeout, the most recently cached debug data
     * is returned instead.
     *
     * @param timeoutMs Timeout for the CAN read.
     * @return Debug data structure containing signal diagnostics.
     */
    AM_LidarDebugData GetDebugData(int timeoutMs = 50);

    /**
     * @brief Get the peak signal strength of the last debug sample.
     */
    uint16_t GetPeakSignalCentiMcps() const;

    /**
     * @brief Get the ambient light level of the last debug sample.
     */
    uint16_t GetAmbientCentiMcps() const;

    /**
     * @brief Returns true if at least one debug frame has been received.
     */
    bool HasDebugData() const;


    /**
     * @brief Set the VL53L1X distance mode on the device.
     * @param mode Distance mode value to send to the device firmware.
     * @return True if the request frame was queued.
     */
    bool SetDistanceMode(AM_LidarDistanceMode mode);

    /**
     * @brief Set measurement timing budget on the device.
     * @param budgetUs Timing budget in microseconds.
     * @return True if the request frame was queued.
     */
    bool SetMeasurementTimingBudgetUs(uint32_t budgetUs);

    /**
     * @brief Set intermeasurement period on the device.
     * @param periodMs Period in milliseconds.
     * @return True if the request frame was queued.
     */
    bool SetIntermeasurementPeriodMs(uint32_t periodMs);

    /**
     * @brief Set the lidar library read timeout on the device.
     * @param timeoutMs Timeout in milliseconds.
     * @return True if the request frame was queued.
     */
    bool SetTimeoutMs(uint16_t timeoutMs);

    /**
     * @brief Set the VL53L1X sigma threshold register value.
     * @param sigma Raw sigma threshold register value.
     * @return True if the request frame was queued.
     */
    bool SetSigmaThreshold(uint16_t sigma);

    /**
     * @brief Set the minimum signal rate threshold on the device.
     *
     * @details
     * Units are MCPS.
     *
     * @param mcps Minimum signal rate in MCPS.
     * @return True if the request frame was queued.
     */
    bool SetMinSignalRate(float mcps);

    /**
     * @brief Set the ROI size on the device.
     * @param width ROI width in SPADs.
     * @param height ROI height in SPADs.
     * @return True if the request frame was queued.
     */
    bool SetROISize(uint8_t width, uint8_t height);

    /**
     * @brief Set the ROI center SPAD on the device.
     * @param centerSpad SPAD number to use as ROI center.
     * @return True if the request frame was queued.
     */
    bool SetROICenter(uint8_t centerSpad);

    /**
     * @brief Set an additional runtime offset applied on top of the default offset.
     * @param offsetMm Additional offset in millimeters.
     *
     * @details
     * Total offset applied to returned readings is:
     *
     *   AM_LIDAR_DEFAULT_OFFSET_MM + offsetMm
     */
    void SetUserOffsetMm(int32_t offsetMm);

    /**
     * @brief Get the currently configured runtime (user) offset in millimeters.
     */
    int32_t GetUserOffsetMm() const;

    /**
     * @brief Get the fixed default offset in millimeters compiled into the library.
     */
    static constexpr int32_t GetDefaultOffsetMm()
    {
        return static_cast<int32_t>(AM_LIDAR_DEFAULT_OFFSET_MM);
    }

    void SetOffsetDegrees(double degrees);
    /**
     * @brief Set periodic report period (ms) for device reports.
     * @param periodMs Period in milliseconds.
     */
    void SetReportPeriod(int periodMs);
    /** @brief Reset device report period to default (50ms). */
    void ResetReportPeriod();
    /** @} */

    /** Last received data cached in the object (distance includes offsets). */
    AM_LidarData data;

private:

    /** Parse the primary data CAN frame into an AM_LidarData structure. */
    void ParseDataFrame(const frc::CANData* frame, AM_LidarData* out);

    /** Parse the debug CAN frame into an AM_LidarDebugData structure. */
    void ParseDebugFrame(const frc::CANData* frame, AM_LidarDebugData* out);

    /** Apply default + user offsets, with clamping to uint16_t range. */
    void ApplyOffsets(AM_LidarData* inOut);

    /** Last raw (un-offset) distance from the device. */
    uint16_t m_lastRawDistanceMm = 0;

    /** Additional runtime offset requested by the user/team (mm). */
    int32_t m_userOffsetMm = 0;

    /** Cached debug information from the most recent debug frame. */
    AM_LidarDebugData m_debug{};
};