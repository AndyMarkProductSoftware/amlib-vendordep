#pragma once

constexpr int SET_REPORT_PERIOD_API = 0x1B; 
constexpr int RESET_REPORT_PERIOD_API = 0x1C;
constexpr int GET_JUNK_DATA = 0x20;

constexpr int RESTART_DEVICE_API = 0x07; //DO THIS

constexpr int MOTOR_CONTROL_SET_SPEED_API = 0x10;
constexpr int MOTOR_CONTROL_SET_BRAKE_COAST_API = 0x11;

constexpr int COLORSENSOR_COLORDATA_API = 0x20;
constexpr int COLORSENSOR_PROX_TIMESTAMP_API = 0x21;

constexpr int ENCODER_ZERO_CURRENT_POS = 0x20;
constexpr int ENCODER_RESET_OFFSET = 0x21;
constexpr int ENCODER_SET_OFFSET = 0x22;
constexpr int ENCODER_TELEMETRY_DATA = 0x23;
constexpr int ENCODER_STATUS_DATA = 0x24;

constexpr int COLOR_LED_ON_OR_OFF = 0x22;

constexpr int HALL_EFFECT_DATA = 0x20;

constexpr int LIDAR_DISTANCE_DATA_TIMESTAMP_API = 0x11;
constexpr int LIDAR_DEBUG_API = 0x12;

constexpr int LIDAR_SET_TIMING_BUDGET_API = 0x30;
constexpr int LIDAR_SET_TIMEOUT_API = 0x31;
constexpr int LIDAR_SET_SIGMA_THRESHOLD_API = 0x32;
constexpr int LIDAR_SET_MIN_SIGNAL_RATE_API = 0x33;
constexpr int LIDAR_SET_ROI_SIZE_API = 0x34;
constexpr int LIDAR_SET_ROI_CENTER_API = 0x35;
constexpr int LIDAR_SET_INTERMEASUREMENT_PERIOD_API = 0x36;
constexpr int LIDAR_SET_MODE_API = 0x37;
