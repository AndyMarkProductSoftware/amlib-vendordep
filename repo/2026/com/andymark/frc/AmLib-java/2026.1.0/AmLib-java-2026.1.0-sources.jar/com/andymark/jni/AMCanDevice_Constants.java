package com.andymark.jni;

public class AMCanDevice_Constants {
    public static final int SET_REPORT_PERIOD_API = 0x1B;
    public static final int RESET_REPORT_PERIOD_API = 0x1C;
    public static final int GET_JUNK_DATA = 0x20;
    public static final int ENCODER_POSITION_API = 0x00;
    public static final int ENCODER_VELOCITY_API = 0x00;
    public static final int RESTART_DEVICE_API = 0x07;

    public static final int MOTOR_CONTROL_SET_SPEED_API = 0x10;
    public static final int MOTOR_CONTROL_SET_BRAKE_COAST_API = 0x11;

    public static final int COLORSENSOR_COLORDATA_API = 0x20;
    public static final int COLORSENSOR_PROX_TIMESTAMP_API = 0x21;

    public static final int ENCODER_ZERO_CURRENT_POS = 0x20;
    public static final int ENCODER_RESET_OFFSET = 0x21;
    public static final int ENCODER_SET_OFFSET = 0x22;
    public static final int ENCODER_TELEMETRY_DATA = 0x23;
    public static final int ENCODER_STATUS_DATA = 0x24;

    public static final int COLOR_LED_ON_OR_OFF = 0x22;

    public static final int HALL_EFFECT_DATA = 0x20;

    public static final int LIDAR_DISTANCE_DATA_TIMESTAMP_API = 0x11;
    public static final int LIDAR_DEBUG_API = 0x12;

    public static final int LIDAR_SET_TIMING_BUDGET_API = 0x30;
    public static final int LIDAR_SET_TIMEOUT_API = 0x31;
    public static final int LIDAR_SET_SIGMA_THRESHOLD_API = 0x32;
    public static final int LIDAR_SET_MIN_SIGNAL_RATE_API = 0x33;
    public static final int LIDAR_SET_ROI_SIZE_API = 0x34;
    public static final int LIDAR_SET_ROI_CENTER_API = 0x35;
    public static final int LIDAR_SET_INTERMEASUREMENT_PERIOD_API = 0x36;
    public static final int LIDAR_SET_MODE_API = 0x37;

}
