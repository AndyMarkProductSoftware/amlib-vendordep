package com.andymark.jni;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import edu.wpi.first.hal.CANData;

/**
 * Time-of-Flight (VL53L1X) lidar device over CAN.
 *
 * Provides access to distance, status, flags, debug signal data,
 * and timestamp over CAN.
 *
 * (c) AndyMark. All rights reserved.
 */
public class AM_CAN_Lidar extends AMCanDevice {

    /**
     * Default mechanical offset (mm) applied to all distance readings.
     *
     * This is the "built-in" offset that accounts for where the actual VL53L1X
     * sensing plane sits inside the product housing / PCB.
     *
     * Teams can add an additional runtime offset via setUserOffsetMm().
     *
     * Positive offset increases the reported distance.
     * Negative offset decreases the reported distance.
     */
    public static final int AM_LIDAR_DEFAULT_OFFSET_MM = 0;

    /**
     * VL53L1X distance mode selection.
     *
     * This controls the sensor's internal ranging profile.
     */
    public enum AM_LidarDistanceMode {
        kShort(0),
        kMedium(1),
        kLong(2);

        private final int value;

        AM_LidarDistanceMode(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    /**
     * Aggregated primary readings from the lidar sensor.
     *
     * This structure represents the main distance measurement frame
     * transmitted by the device.
     *
     * Fields include:
     *  - distance measurement
     *  - device status
     *  - device flags
     *  - device timestamp
     */
    public static class AM_LidarData {

        /**
         * Distance measurement in millimeters.
         *
         * This value already includes both:
         *  - the built-in device offset
         *  - any user-defined offset applied via setUserOffsetMm()
         */
        public int distanceMm;

        /**
         * Device-defined status byte.
         *
         * Indicates measurement validity or sensor state.
         * Typical values may include:
         *  - 0 : measurement valid
         *  - 1 : timeout occurred
         *  - 2 : device initialization failure
         *  - other values correspond to VL53L1X internal range status codes.
         */
        public int status;

        /**
         * Device-defined flags byte.
         *
         * Bitfield providing additional diagnostic information about the measurement.
         * Teams typically do not need this for normal gameplay use,
         * but it can be useful for debugging sensor performance.
         */
        public int flags;

        /**
         * Timestamp of the measurement in milliseconds since device boot.
         */
        public int millisStamp;
    }

    /**
     * Additional diagnostic signal information from the lidar sensor.
     *
     * This data is transmitted periodically using a debug CAN frame.
     * These values help diagnose sensor performance issues such as
     * low reflectivity targets, bright ambient lighting, or poor mounting angles.
     */
    public static class AM_LidarDebugData {

        /**
         * Peak return signal strength.
         *
         * Measured in centi-MCPS (0.01 Mega Counts Per Second).
         */
        public int peakSignalCentiMcps;

        /**
         * Ambient light level detected by the sensor.
         *
         * Also measured in centi-MCPS.
         */
        public int ambientCentiMcps;

        /**
         * Timestamp of the diagnostic sample in milliseconds since device boot.
         */
        public int millisStamp;

        /**
         * Indicates whether a debug frame has been received yet.
         */
        public boolean valid;
    }

    /** Persistent data buffer for the most recent reading. */
    private final AM_LidarData data = new AM_LidarData();

    /** Last raw (un-offset) distance from the device. */
    private int m_lastRawDistanceMm = 0;

    /** Additional runtime offset requested by the user/team (mm). */
    private int m_userOffsetMm = 0;

    /** Cached debug information from the most recent debug frame. */
    private final AM_LidarDebugData m_debug = new AM_LidarDebugData();

    /**
     * Construct a CAN lidar sensor with the given CAN ID.
     *
     * @param deviceID the device's CAN ID
     */
    public AM_CAN_Lidar(int deviceID) {
        super(deviceID, 15, 6);

        data.distanceMm = 0;
        data.status = 0;
        data.flags = 0;
        data.millisStamp = 0;

        m_lastRawDistanceMm = 0;
        m_userOffsetMm = 0;

        m_debug.peakSignalCentiMcps = 0;
        m_debug.ambientCentiMcps = 0;
        m_debug.millisStamp = 0;
        m_debug.valid = false;
    }

    /**
     * Fetch the most recent lidar reading using the default timeout.
     *
     * @return a filled {@link AM_LidarData}
     */
    public AM_LidarData getData() {
        CANData frame = new CANData();

        if (receiveCANMessage(AMCanDevice_Constants.LIDAR_DISTANCE_DATA_TIMESTAMP_API, frame, 150)) {
            parseDataFrame(frame, data);
            applyOffsets(data);

            CANData dbg = new CANData();
            if (receiveCANMessage(AMCanDevice_Constants.LIDAR_DEBUG_API, dbg, 0)) {
                parseDebugFrame(dbg, m_debug);
            }
        }

        return data;
    }

    /**
     * Fetch lidar reading with a custom timeout applied to the CAN read.
     *
     * @param timeoutMs timeout in milliseconds for the CAN read
     * @return a filled {@link AM_LidarData}
     */
    public AM_LidarData getData(int timeoutMs) {
        CANData frame = new CANData();
        AM_LidarData temp = new AM_LidarData();
        temp.distanceMm = 0;
        temp.status = 0;
        temp.flags = 0;
        temp.millisStamp = 0;

        if (receiveCANMessage(AMCanDevice_Constants.LIDAR_DISTANCE_DATA_TIMESTAMP_API, frame, timeoutMs)) {
            parseDataFrame(frame, temp);
            applyOffsets(temp);

            CANData dbg = new CANData();
            if (receiveCANMessage(AMCanDevice_Constants.LIDAR_DEBUG_API, dbg, 0)) {
                parseDebugFrame(dbg, m_debug);
            }
        }

        return temp;
    }

    /**
     * Retrieve the latest debug information from the sensor.
     *
     * Attempts to read a debug CAN frame. If a new frame is not
     * available within the timeout, the most recently cached debug data
     * is returned instead.
     *
     * @param timeoutMs timeout for the CAN read
     * @return debug data structure containing signal diagnostics
     */
    public AM_LidarDebugData getDebugData(int timeoutMs) {
        CANData dbg = new CANData();
        AM_LidarDebugData out = new AM_LidarDebugData();

        out.peakSignalCentiMcps = m_debug.peakSignalCentiMcps;
        out.ambientCentiMcps = m_debug.ambientCentiMcps;
        out.millisStamp = m_debug.millisStamp;
        out.valid = m_debug.valid;

        if (receiveCANMessage(AMCanDevice_Constants.LIDAR_DEBUG_API, dbg, timeoutMs)) {
            parseDebugFrame(dbg, out);

            m_debug.peakSignalCentiMcps = out.peakSignalCentiMcps;
            m_debug.ambientCentiMcps = out.ambientCentiMcps;
            m_debug.millisStamp = out.millisStamp;
            m_debug.valid = out.valid;
        }

        return out;
    }

    /**
     * Retrieve the latest debug information from the sensor.
     *
     * Attempts to read a debug CAN frame. If a new frame is not
     * available within the timeout, the most recently cached debug data
     * is returned instead.
     *
     * @return debug data structure containing signal diagnostics
     */
    public AM_LidarDebugData getDebugData() {
        return getDebugData(50);
    }

    /**
     * Get the peak signal strength of the last debug sample.
     *
     * @return peak signal in centi-MCPS
     */
    public int getPeakSignalCentiMcps() {
        return m_debug.peakSignalCentiMcps;
    }

    /**
     * Get the ambient light level of the last debug sample.
     *
     * @return ambient light in centi-MCPS
     */
    public int getAmbientCentiMcps() {
        return m_debug.ambientCentiMcps;
    }

    /**
     * Returns true if at least one debug frame has been received.
     *
     * @return true if debug data has been received
     */
    public boolean hasDebugData() {
        return m_debug.valid;
    }

    /**
     * Set the VL53L1X distance mode on the device.
     *
     * @param mode distance mode value to send to the device firmware
     * @return true if the request frame was queued
     */
    public boolean setDistanceMode(AM_LidarDistanceMode mode) {
        byte[] payload = new byte[] {
            (byte)(mode.getValue() & 0xFF)
        };
        sendCANMessage(AMCanDevice_Constants.LIDAR_SET_MODE_API, payload);
        return true;
    }

    /**
     * Set measurement timing budget on the device.
     *
     * @param budgetUs timing budget in microseconds
     * @return true if the request frame was queued
     */
    public boolean setMeasurementTimingBudgetUs(int budgetUs) {
        byte[] payload = new byte[] {
            (byte)(budgetUs & 0xFF),
            (byte)((budgetUs >>> 8) & 0xFF),
            (byte)((budgetUs >>> 16) & 0xFF),
            (byte)((budgetUs >>> 24) & 0xFF)
        };

        sendCANMessage(AMCanDevice_Constants.LIDAR_SET_TIMING_BUDGET_API, payload);
        return true;
    }

    /**
     * Set intermeasurement period on the device.
     *
     * @param periodMs period in milliseconds
     * @return true if the request frame was queued
     */
    public boolean setIntermeasurementPeriodMs(int periodMs) {
        byte[] payload = new byte[] {
            (byte)(periodMs & 0xFF),
            (byte)((periodMs >>> 8) & 0xFF),
            (byte)((periodMs >>> 16) & 0xFF),
            (byte)((periodMs >>> 24) & 0xFF)
        };

        sendCANMessage(AMCanDevice_Constants.LIDAR_SET_INTERMEASUREMENT_PERIOD_API, payload);
        return true;
    }

    /**
     * Set the lidar library read timeout on the device.
     *
     * @param timeoutMs timeout in milliseconds
     * @return true if the request frame was queued
     */
    public boolean setTimeoutMs(int timeoutMs) {
        int t = Math.max(0, Math.min(0xFFFF, timeoutMs));
        byte[] payload = new byte[] {
            (byte)(t & 0xFF),
            (byte)((t >>> 8) & 0xFF)
        };

        sendCANMessage(AMCanDevice_Constants.LIDAR_SET_TIMEOUT_API, payload);
        return true;
    }

    /**
     * Set the VL53L1X sigma threshold register value.
     *
     * @param sigma raw sigma threshold register value
     * @return true if the request frame was queued
     */
    public boolean setSigmaThreshold(int sigma) {
        int s = Math.max(0, Math.min(0xFFFF, sigma));
        byte[] payload = new byte[] {
            (byte)(s & 0xFF),
            (byte)((s >>> 8) & 0xFF)
        };

        sendCANMessage(AMCanDevice_Constants.LIDAR_SET_SIGMA_THRESHOLD_API, payload);
        return true;
    }

    /**
     * Set the minimum signal rate threshold on the device.
     *
     * Units are MCPS.
     *
     * @param mcps minimum signal rate in MCPS
     * @return true if the request frame was queued
     */
    public boolean setMinSignalRate(float mcps) {
        byte[] payload = ByteBuffer.allocate(4)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putFloat(mcps)
                .array();

        sendCANMessage(AMCanDevice_Constants.LIDAR_SET_MIN_SIGNAL_RATE_API, payload);
        return true;
    }

    /**
     * Set the ROI size on the device.
     *
     * @param width ROI width in SPADs
     * @param height ROI height in SPADs
     * @return true if the request frame was queued
     */
    public boolean setROISize(int width, int height) {
        byte[] payload = new byte[] {
            (byte)(width & 0xFF),
            (byte)(height & 0xFF)
        };
        sendCANMessage(AMCanDevice_Constants.LIDAR_SET_ROI_SIZE_API, payload);
        return true;
    }

    /**
     * Set the ROI center SPAD on the device.
     *
     * @param centerSpad SPAD number to use as ROI center
     * @return true if the request frame was queued
     */
    public boolean setROICenter(int centerSpad) {
        byte[] payload = new byte[] {
            (byte)(centerSpad & 0xFF)
        };
        sendCANMessage(AMCanDevice_Constants.LIDAR_SET_ROI_CENTER_API, payload);
        return true;
    }

    /**
     * Set an additional runtime offset applied on top of the default offset.
     *
     * @param offsetMm additional offset in millimeters
     *
     * Total offset applied to returned readings is:
     *
     *   AM_LIDAR_DEFAULT_OFFSET_MM + offsetMm
     */
    public void setUserOffsetMm(int offsetMm) {
        m_userOffsetMm = offsetMm;
    }

    /**
     * Get the currently configured runtime (user) offset in millimeters.
     *
     * @return user offset in millimeters
     */
    public int getUserOffsetMm() {
        return m_userOffsetMm;
    }

    /**
     * Get the fixed default offset in millimeters compiled into the library.
     *
     * @return default offset in millimeters
     */
    public static int getDefaultOffsetMm() {
        return AM_LIDAR_DEFAULT_OFFSET_MM;
    }

    public void setOffsetDegrees(double degrees) {
    }

    /**
     * Request a new periodic report interval from the device.
     *
     * @param periodMs period in milliseconds
     * @return true if the request frame was queued
     */
    public boolean setReportPeriod(int periodMs) {
        int p = Math.max(0, Math.min(0xFFFF, periodMs));
        byte[] bytes = new byte[] {
            (byte)(p & 0xFF),
            (byte)((p >>> 8) & 0xFF)
        };
        sendCANMessage(AMCanDevice_Constants.SET_REPORT_PERIOD_API, bytes);
        return true;
    }

    /**
     * Reset the report period to the device default.
     *
     * @return true if the request frame was queued
     */
    public boolean resetReportPeriod() {
        sendCANMessage(AMCanDevice_Constants.RESET_REPORT_PERIOD_API, new byte[0]);
        return true;
    }

    /**
     * Parse the primary data CAN frame into an AM_LidarData structure.
     *
     * @param frame CAN frame
     * @param out output structure
     */
    private void parseDataFrame(CANData frame, AM_LidarData out) {
        byte[] b = frame.data;

        // Data payload:
        // [0]=dist LSB, [1]=dist MSB, [2]=status, [3]=flags, [4..7]=timestamp LE
        final int rawDistance =
                ((b[1] & 0xFF) << 8) |
                ((b[0] & 0xFF));

        m_lastRawDistanceMm = rawDistance;

        out.distanceMm = rawDistance;
        out.status = b[2] & 0xFF;
        out.flags = b[3] & 0xFF;

        out.millisStamp =
                ((b[7] & 0xFF) << 24) |
                ((b[6] & 0xFF) << 16) |
                ((b[5] & 0xFF) << 8)  |
                ((b[4] & 0xFF));
    }

    /**
     * Parse the debug CAN frame into an AM_LidarDebugData structure.
     *
     * @param frame CAN frame
     * @param out output structure
     */
    private void parseDebugFrame(CANData frame, AM_LidarDebugData out) {
        byte[] b = frame.data;

        // Debug payload:
        // [0..1]=peak centiMcps LE, [2..3]=ambient centiMcps LE, [4..7]=timestamp LE
        out.peakSignalCentiMcps =
                ((b[1] & 0xFF) << 8) |
                ((b[0] & 0xFF));

        out.ambientCentiMcps =
                ((b[3] & 0xFF) << 8) |
                ((b[2] & 0xFF));

        out.millisStamp =
                ((b[7] & 0xFF) << 24) |
                ((b[6] & 0xFF) << 16) |
                ((b[5] & 0xFF) << 8)  |
                ((b[4] & 0xFF));

        out.valid = true;
    }

    /**
     * Apply default + user offsets, with clamping to uint16_t range.
     *
     * @param inOut data to modify
     */
    private void applyOffsets(AM_LidarData inOut) {
        final int defaultOffset = AM_LIDAR_DEFAULT_OFFSET_MM;
        final int totalOffset = defaultOffset + m_userOffsetMm;

        int adjusted = inOut.distanceMm + totalOffset;
        adjusted = Math.max(0, Math.min(65535, adjusted));

        inOut.distanceMm = adjusted;
    }
}