package com.andymark.jni;

import edu.wpi.first.wpilibj.CAN;

import com.andymark.jni.AMDiagnosticsServer;

import edu.wpi.first.hal.CANData;

/**
 * Base class for AndyMark CAN devices on the FRC roboRIO CAN bus.
 * <p>
 * Wraps WPILib's {@link CAN} to provide a common transport, message helpers,
 * and device identity.
 * </p>
 */
public class AMCanDevice {
    /** Underlying WPILib CAN endpoint. */
    private final CAN m_can;

    /** Configured CAN device ID. */
    private final int m_deviceID;

    /** Manufacturer code (8-bit). */
    private final int deviceManufacturer;

    /** Device type identifier (matches on-device firmware). */
    private final int deviceType;

    /**
     * Construct a CAN device wrapper.
     *
     * @param deviceID            the 6-bit/8-bit device ID on the CAN bus
     * @param deviceManufacturer  8-bit manufacturer code (e.g., 15 for AndyMark)
     * @param deviceType          device type identifier (matches on-device firmware)
     */
    public AMCanDevice(int deviceID, int deviceManufacturer, int deviceType) {
        AMDiagnosticsServer.ensureServerRunning();

        this.m_can = new CAN(deviceID, deviceManufacturer, deviceType);
        this.m_deviceID = deviceID;
        this.deviceManufacturer = deviceManufacturer;
        this.deviceType = deviceType;
    }

    /**
     * Low-level helper to transmit a CAN packet.
     *
     * @param apiID vendor-specific API ID used to route the message
     * @param data  payload bytes; may be {@code null} when there is no payload
     */
    public void sendCANMessage(int apiID, byte[] data) {
        try
        {
            m_can.writePacket(data, apiID);
        }
        catch(RuntimeException ex)
        {return;}
    }

    /**
     * Receive a packet with a specific API ID, optionally waiting up to a timeout.
     * <p>
     * Wraps WPILib {@link CAN#readPacketTimeout(int, int, CANData)}.
     * </p>
     *
     * @param apiID      expected API ID to match
     * @param data       destination structure for received data
     * @param timeoutMs  maximum time to wait for a packet (milliseconds)
     * @return {@code true} if a matching frame was received within the timeout; {@code false} otherwise
     */
    public boolean receiveCANMessage(int apiID, CANData data, int timeoutMs) {
        return m_can.readPacketTimeout(apiID, timeoutMs, data);
    }

    /**
     * Request a device reboot via CAN command.
     * <p>
     * Sends a vendor-specific API frame defined by {@code RESTART_DEVICE_API}.
     * </p>
     */
    public void restartDevice() {
        sendCANMessage(AMCanDevice_Constants.RESTART_DEVICE_API, null);
    }

    /**
     * Get this device's configured CAN ID.
     *
     * @return the numeric CAN device ID
     */
    public int getDeviceId() {
        return m_deviceID;
    }
}
