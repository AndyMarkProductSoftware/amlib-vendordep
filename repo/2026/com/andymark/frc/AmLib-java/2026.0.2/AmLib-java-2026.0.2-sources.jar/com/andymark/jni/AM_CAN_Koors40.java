package com.andymark.jni;

/**
 * Motor controller API for the Koors40 device.
 * <p>
 * Provides setpoints and mode controls (brake/coast) over CAN.
 * </p>
 * <p>
 * (c) AndyMark. All rights reserved.
 * </p>
 */
public class AM_CAN_Koors40 extends AMCanDevice {

    /**
     * Construct a Koors40 device with the given CAN ID.
     *
     * @param deviceID the device's CAN ID
     */
    public AM_CAN_Koors40(int deviceID) {
        super(deviceID, 15, 2); // 15 = AndyMark vendor ID, 2 = motor controller
    }

    /**
     * Command the motor with a percentage output.
     *
     * @param speed desired output in percent [-100..100]. Values are clamped.
     */
    public void setSpeed(int speed) {
        speed = Math.max(-100, Math.min(100, speed));
        byte[] data = {(byte) speed};
        sendCANMessage(AMCanDevice_Constants.MOTOR_CONTROL_SET_SPEED_API, data);
        //System.out.println("Sent speed: " + speed);
    }

    /**
     * Put the controller in brake (coast disabled) mode.
     */
    public void setBrakeMode() {
        byte[] data = {1};
        sendCANMessage(AMCanDevice_Constants.MOTOR_CONTROL_SET_BRAKE_COAST_API, data);
    }

    /**
     * Put the controller in coast (brake disabled) mode.
     */
    public void setCoastMode() {
        byte[] data = {0};
        sendCANMessage(AMCanDevice_Constants.MOTOR_CONTROL_SET_BRAKE_COAST_API, data);
    }
}
