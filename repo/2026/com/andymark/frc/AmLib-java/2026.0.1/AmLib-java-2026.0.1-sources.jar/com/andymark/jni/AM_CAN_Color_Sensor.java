package com.andymark.jni;

import edu.wpi.first.hal.CANData;

/**
 * Color sensor device over CAN.
 * <p>
 * Provides access to color channels, proximity, and timestamp over CAN.
 * </p>
 * <p>
 * (c) AndyMark. All rights reserved.
 * </p>
 */
public class AM_CAN_Color_Sensor extends AMCanDevice {

    /**
     * Aggregated readings from the color sensor.
     * <p>
     * Includes 16-bit clear/red/green/blue values, an 8-bit proximity reading,
     * and a millisecond timestamp.
     * </p>
     */
    public static class AM_ColorSensorData {
        /** 16-bit color channel value: clear. */ public int clearC;
        /** 16-bit color channel value: red. */   public int red;
        /** 16-bit color channel value: green. */ public int green;
        /** 16-bit color channel value: blue. */  public int blue;
        /** 8-bit proximity metric reported by the sensor. */ public int proximity;
        /** Milliseconds since device boot for the reading. */ public long millisStamp;
    }

    /** Persistent data buffer for the most recent sensor reading. */
    private final AM_ColorSensorData data = new AM_ColorSensorData();

    /**
     * Construct a CAN color sensor with the given CAN ID.
     *
     * @param deviceID the device's CAN ID
     */
    public AM_CAN_Color_Sensor(int deviceID) {
        super(deviceID, 15, 13); // 15 = AndyMark vendor ID, 13 = color sensor
    }

    /**
     * Fetch the most recent color/proximity readings using default timeouts.
     *
     * @return a filled {@link ColorSensorData} structure
     */
    public AM_ColorSensorData getData() {
        final int timeoutMs = 150;
        CANData colorData = new CANData();
        CANData proximityAndTimestamp = new CANData();

        if (receiveCANMessage(AMCanDevice_Constants.COLORSENSOR_COLORDATA_API, colorData, timeoutMs)) {
            byte[] b = colorData.data;
            data.clearC = ((b[1] & 0xFF) << 8) | (b[0] & 0xFF);
            data.red    = ((b[3] & 0xFF) << 8) | (b[2] & 0xFF);
            data.green  = ((b[5] & 0xFF) << 8) | (b[4] & 0xFF);
            data.blue   = ((b[7] & 0xFF) << 8) | (b[6] & 0xFF);
        }

        if (receiveCANMessage(AMCanDevice_Constants.COLORSENSOR_PROX_TIMESTAMP_API, proximityAndTimestamp, timeoutMs)) {
            byte[] p = proximityAndTimestamp.data;
            data.proximity = (p[0] & 0xFF);
            data.millisStamp =
                    ((long) (p[4] & 0xFF) << 24) |
                    ((long) (p[3] & 0xFF) << 16) |
                    ((long) (p[2] & 0xFF) << 8)  |
                    ((long) (p[1] & 0xFF));
        }

        return data;
    }

    /**
     * Fetch color/proximity readings with a custom timeout applied to each API frame.
     *
     * @param timeoutMs timeout in milliseconds for each CAN read
     * @return a filled {@link ColorSensorData} structure
     */
    public AM_ColorSensorData getData(int timeoutMs) {
        AM_ColorSensorData d = new AM_ColorSensorData();
        CANData colorData = new CANData();
        CANData proximityAndTimestamp = new CANData();

        if (receiveCANMessage(AMCanDevice_Constants.COLORSENSOR_COLORDATA_API, colorData, timeoutMs)) {
            byte[] b = colorData.data;
            d.clearC = ((b[1] & 0xFF) << 8) | (b[0] & 0xFF);
            d.red    = ((b[3] & 0xFF) << 8) | (b[2] & 0xFF);
            d.green  = ((b[5] & 0xFF) << 8) | (b[4] & 0xFF);
            d.blue   = ((b[7] & 0xFF) << 8) | (b[6] & 0xFF);
        }

        if (receiveCANMessage(AMCanDevice_Constants.COLORSENSOR_PROX_TIMESTAMP_API, proximityAndTimestamp, timeoutMs)) {
            byte[] p = proximityAndTimestamp.data;
            d.proximity = (p[0] & 0xFF);
            d.millisStamp =
                    ((long) (p[4] & 0xFF) << 24) |
                    ((long) (p[3] & 0xFF) << 16) |
                    ((long) (p[2] & 0xFF) << 8)  |
                    ((long) (p[1] & 0xFF));
        }

        return d;
    }

    /**
     * Request a new periodic report interval from the device.
     *
     * @param period period in milliseconds (device-specific resolution)
     * @return {@code true} if the request frame was queued
     */
    public boolean setReportPeriod(int periodMs) {
        // Clamp to valid uint16 range just in case
        int p = Math.max(0, Math.min(0xFFFF, periodMs));
        byte[] bytes = new byte[] {
            (byte)(p & 0xFF),        // LSB
            (byte)((p >>> 8) & 0xFF) // MSB
        };
        sendCANMessage(AMCanDevice_Constants.SET_REPORT_PERIOD_API, bytes);
        return true; // or return sendCANMessage(...) if it returns a boolean
    }
    

    /**
     * Reset the report period to the device default.
     *
     * @return {@code true} if the request frame was queued
     */
    public boolean resetReportPeriod() {
        sendCANMessage(AMCanDevice_Constants.RESET_REPORT_PERIOD_API, new byte[0]);
        return true;
    }
}
