package com.andymark.jni;

public class AMCanDevice_Constants {
    public static final int SET_REPORT_PERIOD_API = 0x1B;
    public static final int RESET_REPORT_PERIOD_API = 0x1C;
    public static final int GET_JUNK_DATA = 0x20;
    public static final int ENCODER_POSITION_API = 0x00;
    public static final int ENCODER_VELOCITY_API = 0x00;
    public static final int RESTART_DEVICE_API = 0x07;

    public static final int MOTOR_CONTROL_SET_SPEED_API = 0x10;
    public static final int MOTOR_CONTROL_SET_BRAKE_COAST_API = 0x11;

    public static final int COLORSENSOR_COLORDATA_API = 0x20;
    public static final int COLORSENSOR_PROX_TIMESTAMP_API = 0x21;

    public static final int ENCODER_ZERO_CURRENT_POS = 0x20;
    public static final int ENCODER_RESET_OFFSET = 0x21;
    public static final int ENCODER_SET_OFFSET = 0x22;
    public static final int ENCODER_TELEMETRY_DATA = 0x23;
    public static final int ENCODER_STATUS_DATA = 0x24;


}
