package com.andymark.jni;

import edu.wpi.first.wpilibj.RobotBase;
import edu.wpi.first.hal.HAL;
import edu.wpi.first.hal.can.CANJNI;
import edu.wpi.first.hal.CANStreamMessage;

// Depending on WPILib version, you may also have:
// import edu.wpi.first.hal.CANData;        // or CANStreamMessage

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Java diagnostics / reprogramming TCP server.
 * 
 * Protocol and CAN behavior are intended to match the C++ implementation.
 */
public final class AMDiagnosticsServer {

    private static final int DEFAULT_PORT = 12345;

    // Shared state (mirrors anonymous-namespace statics in C++)
    private static final AtomicInteger burstStatus = new AtomicInteger(-1); // -1: waiting, 0: fail, 1: success
    private static final AtomicInteger lastTimestamp = new AtomicInteger(0);
    private static final Object confirmationMonitor = new Object();

    private static volatile int streamHandle = 0;

    private static final AtomicBoolean serverStarted = new AtomicBoolean(false);

    // --- Public API ---------------------------------------------------------

    public static void ensureServerRunning() {
        ensureServerRunning(DEFAULT_PORT);
    }

    public static void ensureServerRunning(int port) {
        if (serverStarted.compareAndSet(false, true)) {
            Thread t = new Thread(() -> serverThreadMain(port), "AMDiag-ServerThread");
            t.setDaemon(true); // do not block JVM exit
            t.start();
        }
    }

    // --- CAN stream helpers -------------------------------------------------

    /**
     * Open a CAN stream that receives only AndyMark messages
     * (manufacturer code in the upper manufacturer bits).
     */
    private static boolean openCanStreamAll() {
        // filter is AndyMark manufacturer code, mask is manufacturer code bits
        int filter = 0x0F << 16;
        int mask   = 0xFF << 16;
        int maxMsgsBuffered = 256;
    
        try {
            // WPILib signature: openCANStreamSession(messageID, messageIDMask, maxMessages)
            int handle = CANJNI.openCANStreamSession(filter, mask, maxMsgsBuffered);
            streamHandle = handle;
            return handle != 0;
        } catch (RuntimeException ex) {
            System.err.println("[AMDiag] openCANStreamSession failed: " + ex.getMessage());
            return false;
        }
    }
    

    private static void closeCanStream() {
        if (streamHandle != 0) {
            try {
                CANJNI.closeCANStreamSession(streamHandle);
            } catch (RuntimeException ex) {
                System.err.println("[AMDiag] closeCANStreamSession failed: " + ex.getMessage());
            }
            streamHandle = 0;
        }
    }
    

    // --- CAN listener thread -----------------------------------------------

    private static void listenForCANMessages(OutputStream out, AtomicBoolean running) {
        if (!openCanStreamAll()) {
            System.err.println("[AMDiag] Open CAN stream failed");
            return;
        }

        // NOTE: exact type here depends on WPILib version.
        // If you have CANStreamMessage, use that.
        // If you have CANData, adapt field names accordingly.
        CANStreamMessage[] msgs = new CANStreamMessage[128];
        for (int i = 0; i < msgs.length; ++i) {
            msgs[i] = new CANStreamMessage();
        }

        byte[] newlineBytes = "\n".getBytes(StandardCharsets.US_ASCII);

        while (running.get()) {
            int readCount;
            try {
                // Assumed signature:
                //   int CANJNI.readStreamSession(int sessionHandle,
                //       CANStreamMessage[] messages, int messagesToRead)
                //
                // Returns number of messages read, or negative on error.
                readCount = CANJNI.readCANStreamSession(streamHandle, msgs, msgs.length);
            } catch (Exception ex) {
                // On error, sleep briefly and continue (similar to status != 0)
                sleepMillis(3);
                continue;
            }

            if (readCount <= 0) {
                // Nothing available right now; avoid busy spinning
                sleepMillis(4);
                continue;
            }

            for (int i = 0; i < readCount; ++i) {
                CANStreamMessage m = msgs[i];
                int messageID = m.messageID;
                byte[] data = m.data;
                int dataSize = m.length & 0xFF;

                int apiCode = (messageID & 0x0000FFC0) >>> 6;

                if (apiCode != 0x05) {
                    // Build: "CAN_MSG <id> d0 d1 ... d7\n"
                    StringBuilder sb = new StringBuilder();
                    sb.append("CAN_MSG ")
                      .append(messageID)
                      .append(' ');

                    for (int b = 0; b < 8; ++b) {
                        int val = (b < dataSize) ? (data[b] & 0xFF) : 0;
                        sb.append(val).append(' ');
                    }

                    try {
                        out.write(sb.toString().getBytes(StandardCharsets.US_ASCII));
                        out.write(newlineBytes);
                        out.flush();
                    } catch (IOException e) {
                        System.err.println("[AMDiag] Socket send failed: " + e.getMessage());
                    }
                } else {
                    // ESP32 confirmation (API 0x05)
                    if (dataSize >= 2) {
                        int successFlag = data[0] & 0xFF;
                        int timestamp   = data[1] & 0xFF;

                        synchronized (confirmationMonitor) {
                            lastTimestamp.set(timestamp);
                            burstStatus.set(successFlag);
                            confirmationMonitor.notifyAll();
                        }
                    }
                }
            }

            sleepMillis(2);
        }

        closeCanStream();
    }

    // --- Per-connection handler --------------------------------------------

    private static void handleConnection(Socket socket) {
        System.out.println("[AMDiag] Connection established");

        AtomicBoolean running = new AtomicBoolean(true);

        try (InputStream in = new BufferedInputStream(socket.getInputStream());
             OutputStream out = new BufferedOutputStream(socket.getOutputStream())) {

            // Start CAN listener thread for this connection
            Thread canListener = new Thread(
                    () -> listenForCANMessages(out, running),
                    "AMDiag-CANListener");
            canListener.setDaemon(true);
            canListener.start();

            // Connection-specific state
            List<Byte> programData = new ArrayList<>();
            int expectedFileLength = 0;
            int receivedBytesCount = 0;
            boolean programModeStarted = false;
            int beginReprogramMessageID = 0;
            int messageBytesMessageID = 0;
            int endReprogramMessageID = 0;

            byte[] buffer = new byte[32768];

            while (true) {
                int bytesRead = in.read(buffer);
                if (bytesRead <= 0) {
                    System.out.println("[AMDiag] Failed to receive data or connection closed");
                    running.set(false);
                    sleepMillis(10);
                    break;
                }

                String receivedData = new String(buffer, 0, bytesRead, StandardCharsets.US_ASCII);
                String[] lines = receivedData.split("\\r?\\n");

                for (String line : lines) {
                    if (line.isEmpty()) {
                        continue;
                    }

                    String[] tokens = line.trim().split("\\s+");
                    if (tokens.length == 0) {
                        continue;
                    }

                    String header = tokens[0];

                    if ("FILE_LENGTH".equals(header)) {
                        if (tokens.length >= 2) {
                            expectedFileLength = Integer.parseInt(tokens[1]);
                            System.out.println("[AMDiag] Expected file length: "
                                    + expectedFileLength + " bytes");
                        }

                    } else if ("CAN_MSG".equals(header)) {
                        if (tokens.length < 2) {
                            continue;
                        }

                        int messageID = (int) Long.parseLong(tokens[1]); // in case it doesn't fit in signed int
                        int apiCode = (messageID >>> 6) & 0x3FF;

                        if (apiCode == 2) {
                            // Step 2: Start reprogramming command
                            byte[] macAddress = new byte[6];
                            for (int i = 2; i < tokens.length && i < 8; ++i) {
                                macAddress[i - 2] =
                                        (byte) Integer.parseInt(tokens[i]);
                            }
                            programModeStarted = true;
                            beginReprogramMessageID = messageID;

                            sendCanMessage(beginReprogramMessageID, macAddress, 6);

                        } else if (apiCode == 3 && programModeStarted) {
                            // Step 3: accumulate program data
                            for (int i = 2; i < tokens.length; ++i) {
                                int val = Integer.parseInt(tokens[i]);
                                programData.add((byte) val);
                                receivedBytesCount++;
                            }
                            messageBytesMessageID = messageID;

                        } else if (apiCode == 4 && programModeStarted) {
                            endReprogramMessageID = messageID;

                            if (receivedBytesCount == expectedFileLength) {
                                System.out.println("[AMDiag] All program bytes received: "
                                        + receivedBytesCount + " bytes");

                                final int BURST_SIZE = 50;
                                int totalMessages = (programData.size() + 6) / 7; // 7-byte chunks
                                int fullBursts = totalMessages / BURST_SIZE;
                                int lastBurstSize = totalMessages % BURST_SIZE;

                                for (int burst = 0; burst <= fullBursts; ) {
                                    boolean retry = true;

                                    while (retry) {
                                        int messagesInBurst = (burst == fullBursts)
                                                ? lastBurstSize
                                                : BURST_SIZE;

                                        
                                        double percent = ((double)(burst + 1) / (double)(fullBursts + 1)) * 100.0;
                                        
                                        System.out.println("[AMDiag] [Progress] Sending burst "
                                                + (burst + 1) + " of " + (fullBursts + 1)
                                                + " (" + String.format("%.1f", percent) + "%, "
                                                + messagesInBurst  + " messages)");
                                        

                                        retry = false;

                                        // If this is the last partial burst, send EOF marker first
                                        if (burst == fullBursts && lastBurstSize > 0) {
                                            byte[] eofMessage = new byte[2];
                                            eofMessage[0] = (byte) 0xFF;
                                            eofMessage[1] = (byte) lastBurstSize;
                                            sendCanMessage(messageBytesMessageID, eofMessage, 2);
                                            System.out.println("[AMDiag] Sent EOF marker to AM Device for final burst");
                                        }

                                        if (messagesInBurst == 0 && fullBursts == 0) {
                                            // No data to send (empty file) – skip bursts loop
                                            break;
                                        }

                                        for (int i = 0; i < messagesInBurst; ++i) {
                                            int dataOffset = (burst * BURST_SIZE + i) * 7;
                                            byte[] frameData = new byte[8];

                                            // index byte
                                            frameData[0] = (byte) i;

                                            int remaining = programData.size() - dataOffset;
                                            int chunkSize = Math.min(7, Math.max(remaining, 0));

                                            for (int b = 0; b < chunkSize; ++b) {
                                                frameData[1 + b] = programData.get(dataOffset + b);
                                            }

                                            int status = sendCanMessage(
                                                    messageBytesMessageID,
                                                    frameData,
                                                    chunkSize + 1
                                            );

                                            if (status != 0) {
                                                System.err.println("[AMDiag] CAN send failed (status = "
                                                        + status + "). Retrying burst...");
                                                retry = true;
                                                break;
                                            }
                                        }

                                        // Wait for ESP32 confirmation
                                        synchronized (confirmationMonitor) {
                                            burstStatus.set(-1);
                                            while (burstStatus.get() == -1) {
                                                try {
                                                    confirmationMonitor.wait();
                                                } catch (InterruptedException ie) {
                                                    Thread.currentThread().interrupt();
                                                    // treat as failure
                                                    burstStatus.set(0);
                                                    break;
                                                }
                                            }

                                            if (burstStatus.get() == 0) {
                                                System.err.println("[AMDiag] AM Device reported failure. Retrying burst...");
                                                retry = true;
                                            } else {
                                                System.out.println("[AMDiag] AM Device confirmed success for burst "
                                                        + burst);
                                                burst++; // only advance on success
                                            }
                                        }
                                    }
                                }

                                // Send final end update message
                                sendCanMessage(endReprogramMessageID, null, 0);
                                System.out.println("[AMDiag] Sent Final Reprogram Message");
                            }

                        } else {
                            // Generic CAN_MSG passthrough
                            List<Byte> messageData = new ArrayList<>();
                            for (int i = 2; i < tokens.length; ++i) {
                                int val = Integer.parseInt(tokens[i]);
                                messageData.add((byte) val);
                            }

                            byte[] payload = new byte[messageData.size()];
                            for (int i = 0; i < payload.length; ++i) {
                                payload[i] = messageData.get(i);
                            }

                            sendCanMessage(messageID, payload, payload.length);
                        }

                    } else if ("START_REPROGRAM".equals(header)) {
                        // START_REPROGRAM <filePath> <startID> <dataID> <endID> <mac0> .. <mac5>
                        if (tokens.length < 4 + 6) {
                            System.err.println("[AMDiag] START_REPROGRAM line malformed: " + line);
                            continue;
                        }

                        String filePath = tokens[1];
                        int startID = (int) Long.parseLong(tokens[2]);
                        int dataID  = (int) Long.parseLong(tokens[3]);
                        int endID   = (int) Long.parseLong(tokens[4]);

                        byte[] mac = new byte[6];
                        for (int i = 0; i < 6; ++i) {
                            mac[i] = (byte) Integer.parseInt(tokens[5 + i]);
                        }

                        byte[] fileBytes;
                        try (InputStream fileIn = new BufferedInputStream(new FileInputStream(filePath))) {
                            fileBytes = fileIn.readAllBytes();
                        } catch (IOException e) {
                            System.err.println("[AMDiag] Failed to open firmware file: "
                                    + filePath + " - " + e.getMessage());
                            continue;
                        }

                        programData.clear();
                        for (byte b : fileBytes) {
                            programData.add(b);
                        }

                        expectedFileLength = fileBytes.length;
                        receivedBytesCount = expectedFileLength;
                        beginReprogramMessageID = startID;
                        messageBytesMessageID  = dataID;
                        endReprogramMessageID  = endID;
                        programModeStarted = true;

                        System.out.println("[AMDiag] [START_REPROGRAM] File loaded: "
                                + filePath + ", " + expectedFileLength + " bytes");

                        sendCanMessage(beginReprogramMessageID, mac, mac.length);
                        System.out.println("[AMDiag] Sent begin reprogram command to AM Device");
                    }
                }
            }

        } catch (IOException e) {
            System.err.println("[AMDiag] Connection handler exception: " + e.getMessage());
        } finally {
            running.set(false);
            try {
                socket.close();
            } catch (IOException ignored) {
            }
            System.out.println("[AMDiag] Cleaning up after disconnect");
        }
    }

    // --- Server thread ------------------------------------------------------

    private static void serverThreadMain(int port) {
        System.out.println("[AMDiag] Diagnostics server starting on port " + port);

        // On C++, we relied on HAL already being initialized by WPILib.
        // In Java, RobotBase/DriverStation/HAL init is handled by WPILib runtime.
        if (!RobotBase.isReal()) {
            System.out.println("[AMDiag] Not running on real hardware; server exiting.");
            return;
        }

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            serverSocket.setReuseAddress(true);
            System.out.println("[AMDiag] Waiting for connection...");

            while (true) {
                try {
                    Socket client = serverSocket.accept();
                    Thread t = new Thread(() -> handleConnection(client), "AMDiag-ClientHandler");
                    t.setDaemon(true);
                    t.start();
                } catch (IOException e) {
                    System.err.println("[AMDiag] Failed to accept connection: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("[AMDiag] Server failed to start: " + e.getMessage());
        }

        System.out.println("[AMDiag] Server thread exiting");
    }

    // --- CAN send helper ----------------------------------------------------

/**
 * Helper to send a CAN frame using CANJNI.
 * Mirrors HAL_CAN_SendMessage(messageID, data, dataSize, HAL_CAN_SEND_PERIOD_NO_REPEAT, &status).
 *
 * @return 0 on success, nonzero on error (so the burst retry logic matches the C++)
 */
private static int sendCanMessage(int messageID, byte[] data, int dataSize) {
    if (data == null) {
        data = new byte[0];
        dataSize = 0;
    }
    if (dataSize > data.length) {
        dataSize = data.length;
    }

    byte[] sendData;
    if (dataSize == data.length) {
        sendData = data;
    } else {
        sendData = new byte[dataSize];
        System.arraycopy(data, 0, sendData, 0, dataSize);
    }

    int periodNoRepeatMs = 0; // HAL_CAN_SEND_PERIOD_NO_REPEAT

    try {
        // WPILib: FRCNetCommCANSessionMuxSendMessage(messageID, data, periodMs)
        CANJNI.FRCNetCommCANSessionMuxSendMessage(messageID, sendData, periodNoRepeatMs);
        return 0;
    } catch (RuntimeException ex) {
        System.err.println("[AMDiag] CAN send error for messageID=0x"
                + Integer.toHexString(messageID) + ": " + ex.getMessage());
        return -1;
    }
}


    // --- Utility ------------------------------------------------------------

    private static void sleepMillis(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
    }

    private AMDiagnosticsServer() {
        // no instantiation
    }
}
