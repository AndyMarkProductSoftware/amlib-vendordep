#include "AMDiagnosticsServer.h"

#include <iostream>
#include <string>
#include <cstring>
#include <thread>
#include <chrono>
#include <sstream>
#include <vector>
#include <iomanip>
#include <regex>
#include <atomic>
#include <mutex>
#include <condition_variable>
#include <fstream>

#include <frc/RobotBase.h>   // for IsReal()
#include <frc/Errors.h>
#include <frc/CAN.h>
#include <hal/CAN.h>
#include <hal/HALBase.h>

#ifndef _WIN32
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <unistd.h>
#endif



namespace andymark {
namespace diag {
 #ifdef _WIN32

void EnsureServerRunning(uint16_t /*port*/) {
    // Windows builds: diagnostics socket server is not supported (POSIX sockets).
    // Do nothing so vendor library compiles for simulation/desktop.
}

#else
   

namespace {

constexpr uint16_t kDefaultPort = 12345;

[[maybe_unused]] int32_t halStatus = 0;

// Counters for tracking received and sent bytes
[[maybe_unused]] size_t totalBytesReceived = 0;
[[maybe_unused]] size_t totalBytesSentToCAN = 0;

// Shared state handling (Pass API code 5 messages to main loop)
std::atomic<int> burstStatus{-1};   // -1: Waiting, 0: Failed, 1: Success
std::atomic<uint8_t> lastTimestamp{0};
std::mutex confirmationMutex;
std::condition_variable confirmationCV;

uint32_t g_streamHandle = 0;

// Server lifetime control
std::once_flag g_serverOnce;
std::atomic<bool> g_serverStarted{false};

bool OpenCanStream_All(int32_t& statusOut) {
    // filter is AndyMark manufacturer code, mask is manufacturer code bits
    uint32_t filter = 0x0F << 16;
    uint32_t mask   = 0xFF << 16;
    const uint32_t kMaxMsgsBuffered = 256;   // how many the mux may queue

    int32_t status = 0;
    HAL_CAN_OpenStreamSession(&g_streamHandle, filter, mask, kMaxMsgsBuffered, &status);
    statusOut = status;
    return status == 0;
}

void CloseCanStream() {
    if (g_streamHandle != 0) {
        HAL_CAN_CloseStreamSession(g_streamHandle);
        g_streamHandle = 0;
    }
}

// Function to listen for CAN messages and send them to the Windows app
void listenForCANMessages(int socketFd, std::atomic<bool>& running) {
    // Open once
    int32_t openStatus = 0;
    if (!OpenCanStream_All(openStatus)) {
        std::cerr << "[AMDiag] Open CAN stream failed, status=" << openStatus << "\n";
        return;
    }

    HAL_CANStreamMessage msgs[128];  // WPILib struct with messageID, data[8], dataSize, timeStamp

    while (running.load()) {
        uint32_t readCount = 0;
        int32_t status = 0;

        // Non-blocking style: ask for up to N available now
        HAL_CAN_ReadStreamSession(g_streamHandle, msgs, std::size(msgs), &readCount, &status);

        if (status != 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(3));
            continue;
        }

        if (readCount == 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(4));
            continue;
        }

        for (uint32_t i = 0; i < readCount; ++i) {
            const auto& m = msgs[i];
            const uint32_t messageID = m.messageID;
            const uint8_t* receivedData = m.data;
            const uint8_t dataSize = m.dataSize;

            const uint32_t apiCode = (messageID & 0x0000FFC0) >> 6;

            if (apiCode != 0x05) {
                std::ostringstream out;
                out << "CAN_MSG " << messageID << " ";
                // Send all 8 bytes for compatibility with your Windows app
                for (int b = 0; b < 8; ++b) {
                    out << int((b < dataSize) ? receivedData[b] : 0) << " ";
                }
                out << "\n";
                const auto s = out.str();
                if (send(socketFd, s.c_str(), s.size(), 0) < 0) {
                    std::cerr << "[AMDiag] Socket send failed\n";
                }
            } else {
                // ESP32 confirmation (API 0x05)
                if (dataSize >= 2) {
                    uint8_t successFlag = receivedData[0];
                    uint8_t timestamp   = receivedData[1];
                    {
                        std::lock_guard<std::mutex> lk(confirmationMutex);
                        lastTimestamp.store(timestamp);
                        burstStatus.store(successFlag);
                    }
                    confirmationCV.notify_one();
                }
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }

    CloseCanStream();
}

// Per-connection handler
void HandleConnection(int new_socket) {
    std::cout << "[AMDiag] Connection established\n";

    // Start a new CAN listener thread
    std::atomic<bool> running(true);
    std::thread canListener(listenForCANMessages, new_socket, std::ref(running));
    canListener.detach();

    // Connection-specific state
    std::vector<uint8_t> programData;
    int expectedFileLength = 0;
    int receivedBytesCount = 0;
    bool programModeStarted = false;
    uint32_t beginReprogramMessageID = 0;
    uint32_t messageBytesMessageID = 0;
    uint32_t endReprogramMessageID = 0;

    // Main loop for this connection
    while (true) {
        char buffer[32768] = {0}; // Buffer to hold received data

        // Receive batched data from the Windows app
        int bytes_received = read(new_socket, buffer, sizeof(buffer));
        if (bytes_received <= 0) {
            std::cout << "[AMDiag] Failed to receive data or connection closed\n";
            running.store(false);         // tell CAN thread to stop
            std::this_thread::sleep_for(std::chrono::milliseconds(10)); // give time to exit
            close(new_socket);            // close socket
            break;
        }

        // Convert buffer to string for line-by-line processing
        std::string receivedData(buffer, bytes_received);
        std::istringstream stream(receivedData);
        std::string line;

        // Process each line in the received batch
        while (std::getline(stream, line)) {
            std::istringstream iss(line);
            std::string messageHeader;
            iss >> messageHeader;

            if (messageHeader == "FILE_LENGTH") {
                // Step 1: Receive file length
                iss >> expectedFileLength;
                std::cout << "[AMDiag] Expected file length: " << expectedFileLength << " bytes\n";

            } else if (messageHeader == "CAN_MSG") {
                uint32_t messageID;
                iss >> messageID;

                // Extract API code from the message ID
                uint16_t apiCode = (messageID >> 6) & 0x3FF;

                // Tokenize the CAN_MSG line into tokens
                std::vector<std::string> tokens;
                std::istringstream lineStream(line);
                std::string token;
                while (lineStream >> token) {
                    tokens.push_back(token);
                }

                if (apiCode == 2) {
                    // Step 2: Start reprogramming command
                    uint8_t macAddress[6] = {0};
                    for (size_t i = 2; i < tokens.size() && i < 8; ++i) {
                        macAddress[i - 2] = static_cast<uint8_t>(std::stoi(tokens[i], nullptr));
                    }
                    programModeStarted = true;
                    beginReprogramMessageID = messageID;

                    int32_t status;
                    HAL_CAN_SendMessage(beginReprogramMessageID, macAddress, 6,
                                        HAL_CAN_SEND_PERIOD_NO_REPEAT, &status);

                } else if (apiCode == 3 && programModeStarted) {
                    // Step 3: Process reprogramming data
                    for (size_t i = 2; i < tokens.size(); ++i) {
                        programData.push_back(static_cast<uint8_t>(
                            std::stoi(tokens[i], nullptr, 10)));
                        receivedBytesCount++;
                    }
                    messageBytesMessageID = messageID;

                } else if (apiCode == 4 && programModeStarted) {
                    // Set end reprogram message ID
                    endReprogramMessageID = messageID;

                    if (receivedBytesCount == expectedFileLength) {
                        std::cout << "[AMDiag] All program bytes received: "
                                  << receivedBytesCount << " bytes\n";

                        const size_t BURST_SIZE = 50;
                        size_t totalMessages = (programData.size() + 6) / 7; // Number of 7-byte chunks
                        size_t fullBursts = totalMessages / BURST_SIZE;
                        size_t lastBurstSize = totalMessages % BURST_SIZE; // Remaining messages

                        for (size_t burst = 0; burst <= fullBursts;) {
                            bool retry = true;

                            while (retry) {
                                double percent =
                                    (static_cast<double>(burst + 1) / static_cast<double>(fullBursts + 1)) * 100.0;
                                
                                std::cout << "[AMDiag] [Progress] Sending burst "
                                          << (burst + 1) << " of " << (fullBursts + 1)
                                          << " (" << std::fixed << std::setprecision(1) << percent << "%, "
                                          << ((burst == fullBursts && lastBurstSize > 0)
                                                ? lastBurstSize
                                                : BURST_SIZE)
                                          << " messages)\n";

                                retry = false;

                                // If this is the last burst and it is partial, send EOF marker first
                                if (burst == fullBursts && lastBurstSize > 0) {
                                    uint8_t eofMessage[8] = {0xFF,
                                                             static_cast<uint8_t>(lastBurstSize)};
                                    HAL_CAN_SendMessage(messageBytesMessageID, eofMessage, 2,
                                                        HAL_CAN_SEND_PERIOD_NO_REPEAT, nullptr);
                                    std::cout << "[AMDiag] Sent EOF marker to AM Device for final burst\n";
                                }

                                size_t messagesInBurst =
                                    (burst == fullBursts) ? lastBurstSize : BURST_SIZE;

                                for (size_t i = 0; i < messagesInBurst; i++) {
                                    size_t dataOffset = (burst * BURST_SIZE + i) * 7;
                                    uint8_t data[8] = {0};

                                    // Index byte
                                    data[0] = static_cast<uint8_t>(i);

                                    // Copy 1–7 bytes of program data after index byte
                                    size_t chunkSize = std::min<size_t>(
                                        7, programData.size() - dataOffset);
                                    std::copy(programData.begin() + dataOffset,
                                              programData.begin() + dataOffset + chunkSize,
                                              &data[1]);

                                    // Send the CAN message
                                    int32_t status;
                                    HAL_CAN_SendMessage(messageBytesMessageID, data,
                                                        chunkSize + 1,
                                                        HAL_CAN_SEND_PERIOD_NO_REPEAT, &status);

                                    if (status != 0) {
                                        std::cerr << "[AMDiag] CAN send failed (status = "
                                                  << status << "). Retrying burst...\n";
                                        retry = true;
                                        break; // exit message loop and retry entire burst
                                    }
                                }

                                // Wait for confirmation from ESP32
                                std::unique_lock<std::mutex> lock(confirmationMutex);
                                burstStatus.store(-1); // reset
                                confirmationCV.wait(lock, [] {
                                    return burstStatus.load() != -1;
                                });

                                if (burstStatus.load() == 0) {
                                    std::cerr << "[AMDiag] AM Device reported failure. Retrying burst...\n";
                                    retry = true;
                                } else {
                                    std::cout << "[AMDiag] AM Device confirmed success for burst "
                                              << burst << "\n";
                                    burst++; // Only increment if burst confirmed
                                }
                            }
                        }

                        // After all bursts are confirmed, send final end update message
                        HAL_CAN_SendMessage(endReprogramMessageID, nullptr, 0,
                                            HAL_CAN_SEND_PERIOD_NO_REPEAT, nullptr);
                        std::cout << "[AMDiag] Sent Final Reprogram Message\n";
                    }
                } else {
                    std::vector<uint8_t> messageData;

                    // Extract data bytes starting from index 2
                    for (size_t i = 2; i < tokens.size(); ++i) {
                        messageData.push_back(static_cast<uint8_t>(
                            std::stoi(tokens[i], nullptr, 10)));
                    }
                    int32_t status;
                    HAL_CAN_SendMessage(messageID, messageData.data(), messageData.size(),
                                        HAL_CAN_SEND_PERIOD_NO_REPEAT, &status);
                }
            } else if (messageHeader == "START_REPROGRAM") {
                std::string filePath;
                uint32_t startID, dataID, endID;
                uint8_t macAddress[6];

                // Parse: file path, 3 IDs, MAC[6]
                iss >> filePath >> startID >> dataID >> endID;
                for (int i = 0; i < 6; ++i) {
                    int byteVal;
                    iss >> byteVal;
                    macAddress[i] = static_cast<uint8_t>(byteVal);
                }

                // Open binary file
                std::ifstream firmwareFile(filePath, std::ios::binary);
                if (!firmwareFile.is_open()) {
                    std::cerr << "[AMDiag] Failed to open firmware file: " << filePath << "\n";
                    continue;
                }

                // Load file contents
                programData.assign(std::istreambuf_iterator<char>(firmwareFile), {});
                firmwareFile.close();

                expectedFileLength = static_cast<int>(programData.size());
                receivedBytesCount = expectedFileLength;
                beginReprogramMessageID = startID;
                messageBytesMessageID = dataID;
                endReprogramMessageID = endID;
                programModeStarted = true;

                std::cout << "[AMDiag] [START_REPROGRAM] File loaded: "
                          << filePath << ", " << expectedFileLength << " bytes\n";

                // Send the initial "begin update" CAN message
                int32_t status;
                HAL_CAN_SendMessage(beginReprogramMessageID, macAddress, 6,
                                    HAL_CAN_SEND_PERIOD_NO_REPEAT, &status);
                std::cout << "[AMDiag] Sent begin reprogram command to AM Device\n";
            }
        }
    }

    std::cout << "[AMDiag] Cleaning up after disconnect\n";
}

// Server thread entry point
void ServerThreadMain(uint16_t port) {
    std::cout << "[AMDiag] Diagnostics server starting on port " << port << "\n";

    // We assume HAL is already initialized by WPILib.
    if (!frc::RobotBase::IsReal()) {
        std::cout << "[AMDiag] Not running on real hardware; server exiting.\n";
        return;
    }

    int server_fd;
    struct sockaddr_in address {};
    int addrlen = sizeof(address);

    // Create socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == 0) {
        std::cout << "[AMDiag] Socket creation failed\n";
        return;
    }

    int opt = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                   &opt, sizeof(opt))) {
        std::cout << "[AMDiag] setsockopt failed\n";
        close(server_fd);
        return;
    }

    // Configure server address
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(port);

    // Bind socket to the port
    if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
        std::cout << "[AMDiag] Bind failed\n";
        close(server_fd);
        return;
    }

    // Listen for incoming connections
    if (listen(server_fd, 3) < 0) {
        std::cout << "[AMDiag] Listen failed\n";
        close(server_fd);
        return;
    }

    std::cout << "[AMDiag] Waiting for connection...\n";

    // Accept-loop
    while (true) {
        int new_socket = accept(server_fd,
                                (struct sockaddr*)&address,
                                (socklen_t*)&addrlen);
        if (new_socket < 0) {
            std::cout << "[AMDiag] Failed to accept connection\n";
            continue;
        }

        // Spawn a handler thread per connection
        std::thread(HandleConnection, new_socket).detach();
    }

    // Should never get here unless accept loop ends
    close(server_fd);
    std::cout << "[AMDiag] Server thread exiting\n";
}

}  // namespace

void EnsureServerRunning(uint16_t port) {
    // Only start once
    std::call_once(g_serverOnce, [port]() {
        g_serverStarted.store(true);
        std::thread(ServerThreadMain, port).detach();
    });
}

#endif  // _WIN32

}  // namespace diag
}  // namespace andymark


