#include "AM_CAN_Lidar.h"

#include <algorithm>  // std::clamp
#include <cstring>    // std::memcpy

AM_CANLidar::AM_CANLidar(int busId, int deviceID)
    : CanDevice(busId, deviceID, 15, 6)
{
    data.distanceMm = 0;
    data.status = 0;
    data.flags = 0;
    data.millisStamp = 0;

    m_lastRawDistanceMm = 0;
    m_userOffsetMm = 0;

    m_debug.peakSignalCentiMcps = 0;
    m_debug.ambientCentiMcps = 0;
    m_debug.millisStamp = 0;
    m_debug.valid = false;
}

void AM_CANLidar::SetUserOffsetMm(int32_t offsetMm)
{
    m_userOffsetMm = offsetMm;
}

int32_t AM_CANLidar::GetUserOffsetMm() const
{
    return m_userOffsetMm;
}

void AM_CANLidar::ParseDataFrame(const HAL_CANReceiveMessage* frame, AM_LidarData* out)
{
    // Data payload:
    // [0]=dist LSB, [1]=dist MSB, [2]=status, [3]=flags, [4..7]=timestamp LE
    const uint16_t rawDistance =
        (static_cast<uint16_t>(frame->message.data[1]) << 8) |
        (static_cast<uint16_t>(frame->message.data[0]));

    m_lastRawDistanceMm = rawDistance;

    out->distanceMm = rawDistance;
    out->status = static_cast<uint8_t>(frame->message.data[2]);
    out->flags  = static_cast<uint8_t>(frame->message.data[3]);

    out->millisStamp =
        (static_cast<uint32_t>(frame->message.data[7]) << 24) |
        (static_cast<uint32_t>(frame->message.data[6]) << 16) |
        (static_cast<uint32_t>(frame->message.data[5]) <<  8) |
        (static_cast<uint32_t>(frame->message.data[4]) <<  0);
}

void AM_CANLidar::ParseDebugFrame(const HAL_CANReceiveMessage* frame, AM_LidarDebugData* out)
{
    // Debug payload:
    // [0..1]=peak centiMcps LE, [2..3]=ambient centiMcps LE, [4..7]=timestamp LE
    out->peakSignalCentiMcps =
        (static_cast<uint16_t>(frame->message.data[1]) << 8) |
        (static_cast<uint16_t>(frame->message.data[0]));

    out->ambientCentiMcps =
        (static_cast<uint16_t>(frame->message.data[3]) << 8) |
        (static_cast<uint16_t>(frame->message.data[2]));

    out->millisStamp =
        (static_cast<uint32_t>(frame->message.data[7]) << 24) |
        (static_cast<uint32_t>(frame->message.data[6]) << 16) |
        (static_cast<uint32_t>(frame->message.data[5]) <<  8) |
        (static_cast<uint32_t>(frame->message.data[4]) <<  0);

    out->valid = true;
}

void AM_CANLidar::ApplyOffsets(AM_LidarData* inOut)
{
    const int32_t defaultOffset = static_cast<int32_t>(AM_LIDAR_DEFAULT_OFFSET_MM);
    const int32_t totalOffset = defaultOffset + m_userOffsetMm;

    int32_t adjusted = static_cast<int32_t>(inOut->distanceMm) + totalOffset;
    adjusted = std::clamp(adjusted, 0, 65535);

    inOut->distanceMm = static_cast<uint16_t>(adjusted);
}

AM_LidarData AM_CANLidar::GetData()
{
    HAL_CANReceiveMessage frame{};

    if (ReceiveCANMessage(LIDAR_DISTANCE_DATA_TIMESTAMP_API, &frame, 150))
    {
        ParseDataFrame(&frame, &data);
        ApplyOffsets(&data);

        HAL_CANReceiveMessage dbg{};
        if (ReceiveCANMessage(LIDAR_DEBUG_API, &dbg, 0))
        {
            ParseDebugFrame(&dbg, &m_debug);
        }
    }

    return data;
}

AM_LidarData AM_CANLidar::GetData(int timeoutMs)
{
    HAL_CANReceiveMessage frame{};
    AM_LidarData temp{};
    temp.distanceMm = 0;
    temp.status = 0;
    temp.flags = 0;
    temp.millisStamp = 0;

    if (ReceiveCANMessage(LIDAR_DISTANCE_DATA_TIMESTAMP_API, &frame, timeoutMs))
    {
        ParseDataFrame(&frame, &temp);
        ApplyOffsets(&temp);

        HAL_CANReceiveMessage dbg{};
        if (ReceiveCANMessage(LIDAR_DEBUG_API, &dbg, 0))
        {
            ParseDebugFrame(&dbg, &m_debug);
        }
    }

    return temp;
}

AM_LidarDebugData AM_CANLidar::GetDebugData(int timeoutMs)
{
    HAL_CANReceiveMessage dbg{};
    AM_LidarDebugData out = m_debug;

    if (ReceiveCANMessage(LIDAR_DEBUG_API, &dbg, timeoutMs))
    {
        ParseDebugFrame(&dbg, &out);
        m_debug = out;
    }

    return out;
}

uint16_t AM_CANLidar::GetPeakSignalCentiMcps() const
{
    return m_debug.peakSignalCentiMcps;
}

uint16_t AM_CANLidar::GetAmbientCentiMcps() const
{
    return m_debug.ambientCentiMcps;
}

bool AM_CANLidar::HasDebugData() const
{
    return m_debug.valid;
}



bool AM_CANLidar::SetDistanceMode(AM_LidarDistanceMode mode)
{
    uint8_t payload[1] = { static_cast<uint8_t>(mode) };
    SendCANMessage(LIDAR_SET_MODE_API, payload, 1);
    return true;
}

bool AM_CANLidar::SetMeasurementTimingBudgetUs(uint32_t budgetUs)
{
    uint8_t payload[4];
    payload[0] = static_cast<uint8_t>(budgetUs & 0xFF);
    payload[1] = static_cast<uint8_t>((budgetUs >> 8) & 0xFF);
    payload[2] = static_cast<uint8_t>((budgetUs >> 16) & 0xFF);
    payload[3] = static_cast<uint8_t>((budgetUs >> 24) & 0xFF);

    SendCANMessage(LIDAR_SET_TIMING_BUDGET_API, payload, 4);
    return true;
}

bool AM_CANLidar::SetIntermeasurementPeriodMs(uint32_t periodMs)
{
    uint8_t payload[4];
    payload[0] = static_cast<uint8_t>(periodMs & 0xFF);
    payload[1] = static_cast<uint8_t>((periodMs >> 8) & 0xFF);
    payload[2] = static_cast<uint8_t>((periodMs >> 16) & 0xFF);
    payload[3] = static_cast<uint8_t>((periodMs >> 24) & 0xFF);

    SendCANMessage(LIDAR_SET_INTERMEASUREMENT_PERIOD_API, payload, 4);
    return true;
}

bool AM_CANLidar::SetTimeoutMs(uint16_t timeoutMs)
{
    uint8_t payload[2];
    payload[0] = static_cast<uint8_t>(timeoutMs & 0xFF);
    payload[1] = static_cast<uint8_t>((timeoutMs >> 8) & 0xFF);

    SendCANMessage(LIDAR_SET_TIMEOUT_API, payload, 2);
    return true;
}


bool AM_CANLidar::SetSigmaThreshold(uint16_t sigma)
{
    uint8_t payload[2];
    payload[0] = static_cast<uint8_t>(sigma & 0xFF);
    payload[1] = static_cast<uint8_t>((sigma >> 8) & 0xFF);

    SendCANMessage(LIDAR_SET_SIGMA_THRESHOLD_API, payload, 2);
    return true;
}

bool AM_CANLidar::SetMinSignalRate(float mcps)
{
    uint8_t payload[4];
    static_assert(sizeof(float) == 4, "Expected 32-bit float");

    std::memcpy(payload, &mcps, sizeof(float));

    SendCANMessage(LIDAR_SET_MIN_SIGNAL_RATE_API, payload, 4);
    return true;
}

bool AM_CANLidar::SetROISize(uint8_t width, uint8_t height)
{
    uint8_t payload[2] = { width, height };
    SendCANMessage(LIDAR_SET_ROI_SIZE_API, payload, 2);
    return true;
}

bool AM_CANLidar::SetROICenter(uint8_t centerSpad)
{
    uint8_t payload[1] = { centerSpad };
    SendCANMessage(LIDAR_SET_ROI_CENTER_API, payload, 1);
    return true;
}

void AM_CANLidar::SetReportPeriod(int periodMs) {
    uint16_t p = static_cast<uint16_t>(periodMs);
    uint8_t data[2] = {
        static_cast<uint8_t>(p & 0xFF),
        static_cast<uint8_t>((p >> 8) & 0xFF)
    };
    SendCANMessage(SET_REPORT_PERIOD_API, data, 2);
}

void AM_CANLidar::ResetReportPeriod() {
    SendCANMessage(RESET_REPORT_PERIOD_API, nullptr, 0);
}
