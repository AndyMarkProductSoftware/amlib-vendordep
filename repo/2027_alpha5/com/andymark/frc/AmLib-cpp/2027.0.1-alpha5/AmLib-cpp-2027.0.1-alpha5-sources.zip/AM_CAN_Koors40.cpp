#include "AM_CAN_Koors40.h"
#include <iostream>

CAN_Koors40::CAN_Koors40(int busId, int deviceID)
    : CanDevice(busId, deviceID,15,2) {} //15 is AndyMark vendor ID, 2 is motor contoller device type

void CAN_Koors40::setSpeed(int speed){

    speed = std::min(100, std::max(-100,speed));
    uint8_t data[1] = {(uint8_t)speed};
    SendCANMessage(MOTOR_CONTROL_SET_SPEED_API, data, 1);
    //std::cout << "sent message " << speed << std::endl; 
}

void CAN_Koors40::setBrakeMode(){
    uint8_t data[1] = {1};
    SendCANMessage(MOTOR_CONTROL_SET_BRAKE_COAST_API, data, 1);
}
  
void CAN_Koors40::setCoastMode(){
    uint8_t data[1] = {0};
    SendCANMessage(MOTOR_CONTROL_SET_BRAKE_COAST_API, data, 1);
}
