#include "AMDiagnosticsServer.h"

#include <iostream>
#include <string>
#include <cstring>
#include <algorithm>
#include <thread>
#include <chrono>
#include <sstream>
#include <vector>
#include <iomanip>
#include <array>
#include <regex>
#include <atomic>
#include <mutex>
#include <condition_variable>
#include <fstream>


#include <wpi/framework/RobotBase.hpp>
#include <wpi/hardware/bus/CAN.hpp>
#include <wpi/driverstation/DriverStation.hpp>
#include <wpi/hal/CAN.h>
#include <wpi/hal/DriverStation.h>

#ifndef _WIN32
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <unistd.h>
#endif



namespace andymark {
namespace diag {
 #ifdef _WIN32

void EnsureServerRunning(uint16_t /*port*/) {
    // Windows builds: diagnostics socket server is not supported (POSIX sockets).
    // Do nothing so vendor library compiles for simulation/desktop.
}

#else
   

namespace {

constexpr uint16_t kDefaultPort = 12345;
constexpr int kCanBusCount = 5;

void CloseCanStream();

[[maybe_unused]] int32_t halStatus = 0;

// Counters for tracking received and sent bytes
[[maybe_unused]] size_t totalBytesReceived = 0;
[[maybe_unused]] size_t totalBytesSentToCAN = 0;

struct BusConfirmationState {
    std::atomic<int> burstStatus{-1};   // -1: Waiting, 0: Failed, 1: Success
    std::atomic<uint8_t> lastTimestamp{0};
};

std::mutex confirmationMutex;
std::condition_variable confirmationCV;

std::array<HAL_CANStreamHandle, kCanBusCount> g_streamHandles{};
std::array<BusConfirmationState, kCanBusCount> g_confirmations;

// Server lifetime control
std::once_flag g_serverOnce;
std::atomic<bool> g_serverStarted{false};

bool OpenCanStream_All(int32_t& statusOut) {
    // filter is AndyMark manufacturer code, mask is manufacturer code bits
    uint32_t filter = 0x0F << 16;
    uint32_t mask   = 0xFF << 16;
    const uint32_t kMaxMsgsBuffered = 256;   // how many the mux may queue

    for (int busId = 0; busId < kCanBusCount; ++busId) {
        int32_t status = 0;
        g_streamHandles[busId] =
            HAL_CAN_OpenStreamSession(busId, filter, mask, kMaxMsgsBuffered, &status);

        if (status != 0 || g_streamHandles[busId] == 0) {
            statusOut = status != 0 ? status : -1;
            CloseCanStream();
            return false;
        }
    }

    statusOut = 0;
    return true;
}

void CloseCanStream() {
    for (auto& handle : g_streamHandles) {
        if (handle != 0) {
            HAL_CAN_CloseStreamSession(handle);
            handle = 0;
        }
    }
}

bool SendCanMessage(int busId, uint32_t messageId, const uint8_t* data, int length,
                    int32_t* statusOut = nullptr) {
    if (busId < 0 || busId >= kCanBusCount) {
        if (statusOut != nullptr) {
            *statusOut = -1;
        }
        return false;
    }

    HAL_CANMessage message{};
    const int payloadLength =
        std::clamp(length, 0, static_cast<int>(sizeof(message.data)));
    message.dataSize = static_cast<uint8_t>(payloadLength);
    if (payloadLength > 0 && data != nullptr) {
        std::memcpy(message.data, data, static_cast<size_t>(payloadLength));
    }

    int32_t status = 0;
    HAL_CAN_SendMessage(busId, messageId, &message, HAL_CAN_SEND_PERIOD_NO_REPEAT,
                        &status);

    if (statusOut != nullptr) {
        *statusOut = status;
    }

    return status == 0;
}

// Function to listen for CAN messages and send them to the Windows app
void listenForCANMessages(int socketFd, std::atomic<bool>& running) {
    // Open once
    int32_t openStatus = 0;
    if (!OpenCanStream_All(openStatus)) {
        std::cerr << "[AMDiag] Open CAN stream failed, status=" << openStatus << "\n";
        return;
    }

    HAL_CANStreamMessage msgs[128];

    while (running.load()) {
        bool anyMessages = false;

        for (int busId = 0; busId < kCanBusCount; ++busId) {
            if (g_streamHandles[busId] == 0) {
                continue;
            }

            uint32_t readCount = 0;
            int32_t status = 0;

            HAL_CAN_ReadStreamSession(
                g_streamHandles[busId], msgs, std::size(msgs), &readCount, &status);

            if (status != 0 || readCount == 0) {
                continue;
            }

            anyMessages = true;

            for (uint32_t i = 0; i < readCount; ++i) {
                const auto& m = msgs[i];
                const uint32_t messageID = m.messageId;
                const uint8_t* receivedData = m.message.message.data;
                const uint8_t dataSize = m.message.message.dataSize;

                const uint32_t apiCode = (messageID & 0x0000FFC0) >> 6;

                if (apiCode != 0x05) {
                    std::ostringstream out;
                    out << "CAN_MSG " << busId << " " << messageID << " ";
                    // Send all 8 bytes for compatibility with Windows app
                    for (int b = 0; b < 8; ++b) {
                        out << int((b < dataSize) ? receivedData[b] : 0) << " ";
                    }
                    out << "\n";
                    const auto s = out.str();
                    if (send(socketFd, s.c_str(), s.size(), 0) < 0) {
                        std::cerr << "[AMDiag] Socket send failed\n";
                    }
                } else {
                    // Confirmation handling is tracked per bus so replies from one bus
                    // cannot satisfy a reprogram burst running on another.
                    if (dataSize >= 2) {
                        {
                            std::lock_guard<std::mutex> lk(confirmationMutex);
                            g_confirmations[busId].lastTimestamp.store(receivedData[1]);
                            g_confirmations[busId].burstStatus.store(receivedData[0]);
                        }
                        confirmationCV.notify_all();
                    }
                }
            }
        }

        std::this_thread::sleep_for(anyMessages
                                        ? std::chrono::milliseconds(2)
                                        : std::chrono::milliseconds(4));
    }

    CloseCanStream();
}

// Per-connection handler
void HandleConnection(int new_socket) {
    HAL_SendConsoleLine("[AMDiag] All program bytes received");

    // Start a new CAN listener thread
    std::atomic<bool> running(true);
    std::thread canListener(listenForCANMessages, new_socket, std::ref(running));
    canListener.detach();

    // Connection-specific state
    std::vector<uint8_t> programData;
    int expectedFileLength = 0;
    int receivedBytesCount = 0;
    bool programModeStarted = false;
    uint32_t beginReprogramMessageID = 0;
    uint32_t messageBytesMessageID = 0;
    uint32_t endReprogramMessageID = 0;
    int activeBusId = 0;

    // Main loop for this connection
    while (true) {
        char buffer[32768] = {0}; // Buffer to hold received data

        // Receive batched data from the Windows app
        int bytes_received = read(new_socket, buffer, sizeof(buffer));
        if (bytes_received <= 0) {
            HAL_SendConsoleLine("[AMDiag] Failed to receive data or connection closed");
            running.store(false);         // tell CAN thread to stop
            std::this_thread::sleep_for(std::chrono::milliseconds(10)); // give time to exit
            close(new_socket);            // close socket
            break;
        }

        // Convert buffer to string for line-by-line processing
        std::string receivedData(buffer, bytes_received);
        std::istringstream stream(receivedData);
        std::string line;

        // Process each line in the received batch
        while (std::getline(stream, line)) {
            std::istringstream iss(line);
            std::string messageHeader;
            iss >> messageHeader;

            if (messageHeader == "FILE_LENGTH") {
                // Step 1: Receive file length
                iss >> expectedFileLength;
                std::ostringstream __amdiag_ss;
                __amdiag_ss << "[AMDiag] Expected file length: " << expectedFileLength << " bytes";
                HAL_SendConsoleLine(__amdiag_ss.str().c_str());

            } else if (messageHeader == "CAN_MSG") {
                int busId = 0;
                uint32_t messageID = 0;
                iss >> busId >> messageID;

                if (busId < 0 || busId >= kCanBusCount) {
                    std::cerr << "[AMDiag] Ignoring CAN_MSG with invalid busId "
                              << busId << "\n";
                    continue;
                }

                activeBusId = busId;

                // Extract API code from the message ID
                uint16_t apiCode = (messageID >> 6) & 0x3FF;

                // Tokenize the CAN_MSG line into tokens
                std::vector<std::string> tokens;
                std::istringstream lineStream(line);
                std::string token;
                while (lineStream >> token) {
                    tokens.push_back(token);
                }

                if (apiCode == 2) {
                    // Step 2: Start reprogramming command
                    uint8_t macAddress[6] = {0};
                    for (size_t i = 3; i < tokens.size() && i < 9; ++i) {
                        macAddress[i - 3] = static_cast<uint8_t>(std::stoi(tokens[i], nullptr));
                    }
                    programModeStarted = true;
                    beginReprogramMessageID = messageID;

                    int32_t status;
                    SendCanMessage(activeBusId, beginReprogramMessageID, macAddress, 6,
                                   &status);

                } else if (apiCode == 3 && programModeStarted) {
                    // Step 3: Process reprogramming data
                    for (size_t i = 3; i < tokens.size(); ++i) {
                        programData.push_back(static_cast<uint8_t>(
                            std::stoi(tokens[i], nullptr, 10)));
                        receivedBytesCount++;
                    }
                    messageBytesMessageID = messageID;

                } else if (apiCode == 4 && programModeStarted) {
                    // Set end reprogram message ID
                    endReprogramMessageID = messageID;

                    if (receivedBytesCount == expectedFileLength) {
                        std::ostringstream __amdiag_ss;
                        __amdiag_ss << "[AMDiag] All program bytes received: "
                                    << receivedBytesCount << " bytes";
                        HAL_SendConsoleLine(__amdiag_ss.str().c_str());

                        const size_t BURST_SIZE = 50;
                        size_t totalMessages = (programData.size() + 6) / 7; // Number of 7-byte chunks
                        size_t fullBursts = totalMessages / BURST_SIZE;
                        size_t lastBurstSize = totalMessages % BURST_SIZE; // Remaining messages

                        for (size_t burst = 0; burst <= fullBursts;) {
                            bool retry = true;

                            while (retry) {
                                double percent =
                                    (static_cast<double>(burst + 1) / static_cast<double>(fullBursts + 1)) * 100.0;
                                
                                std::ostringstream __amdiag_ss2;
                                __amdiag_ss2 << "[AMDiag] [Progress] Sending burst "
                                             << (burst + 1) << " of " << (fullBursts + 1)
                                             << " (" << std::fixed << std::setprecision(1) << percent << "%, "
                                             << ((burst == fullBursts && lastBurstSize > 0)
                                                   ? lastBurstSize
                                                   : BURST_SIZE)
                                             << " messages)";
                                HAL_SendConsoleLine(__amdiag_ss2.str().c_str());

                                retry = false;

                                // If this is the last burst and it is partial, send EOF marker first
                                if (burst == fullBursts && lastBurstSize > 0) {
                                    uint8_t eofMessage[8] = {0xFF,
                                                             static_cast<uint8_t>(lastBurstSize)};
                                    SendCanMessage(activeBusId, messageBytesMessageID, eofMessage, 2);
                                    HAL_SendConsoleLine("[AMDiag] Sent EOF marker to AM Device for final burst");
                                }

                                size_t messagesInBurst =
                                    (burst == fullBursts) ? lastBurstSize : BURST_SIZE;

                                for (size_t i = 0; i < messagesInBurst; i++) {
                                    size_t dataOffset = (burst * BURST_SIZE + i) * 7;
                                    uint8_t data[8] = {0};

                                    // Index byte
                                    data[0] = static_cast<uint8_t>(i);

                                    // Copy 1â€“7 bytes of program data after index byte
                                    size_t chunkSize = std::min<size_t>(
                                        7, programData.size() - dataOffset);
                                    std::copy(programData.begin() + dataOffset,
                                              programData.begin() + dataOffset + chunkSize,
                                              &data[1]);

                                    // Send the CAN message
int32_t status;
SendCanMessage(activeBusId, messageBytesMessageID, data,
               static_cast<int>(chunkSize + 1), &status);

if (status != 0) {
    std::cerr << "[AMDiag] CAN send failed (status = "
              << status << "). Backing off and retrying burst...\n";

    // Give the roboRIO CAN output queue time to drain before retrying.
    // -35007 is typically CAN output buffer full.
    std::this_thread::sleep_for(std::chrono::milliseconds(10));

    retry = true;
    break;
}

// Light pacing to avoid filling the roboRIO CAN output buffer.
// This adds about 5 ms per 50-frame burst, not 1 ms per frame.
if ((i % 10) == 9) {
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
}
                                }


                                
                                // Wait for confirmation from ESP32
                                std::unique_lock<std::mutex> lock(confirmationMutex);
                                g_confirmations[activeBusId].burstStatus.store(-1); // reset
                                confirmationCV.wait(lock, [&activeBusId] {
                                    return g_confirmations[activeBusId].burstStatus.load() != -1;
                                });

                                if (g_confirmations[activeBusId].burstStatus.load() == 0) {
                                    std::cerr << "[AMDiag] AM Device reported failure. Retrying burst...\n";
                                    retry = true;
                                } else {
                                    std::ostringstream __amdiag_ss4;
                                    __amdiag_ss4 << "[AMDiag] AM Device confirmed success for burst "
                                                 << burst;
                                    HAL_SendConsoleLine(__amdiag_ss4.str().c_str());
                                    burst++; // Only increment if burst confirmed
                                }
                            }
                        }

                        // After all bursts are confirmed, send final end update message
                        SendCanMessage(activeBusId, endReprogramMessageID, nullptr, 0);
                        HAL_SendConsoleLine("[AMDiag] Sent Final Reprogram Message");
                    }
                } else {
                    std::vector<uint8_t> messageData;

                    // Extract data bytes starting from index 2
                    for (size_t i = 3; i < tokens.size(); ++i) {
                        messageData.push_back(static_cast<uint8_t>(
                            std::stoi(tokens[i], nullptr, 10)));
                    }
                    int32_t status;
                    SendCanMessage(activeBusId, messageID, messageData.data(),
                                   static_cast<int>(messageData.size()), &status);
                }
            } else if (messageHeader == "START_REPROGRAM") {
                std::string filePath;
                int busId = 0;
                uint32_t startID, dataID, endID;
                uint8_t macAddress[6];

                // Parse: busId, file path, 3 IDs, MAC[6]
                iss >> busId >> filePath >> startID >> dataID >> endID;
                if (busId < 0 || busId >= kCanBusCount) {
                    std::cerr << "[AMDiag] Ignoring START_REPROGRAM with invalid busId "
                              << busId << "\n";
                    continue;
                }
                activeBusId = busId;
                for (int i = 0; i < 6; ++i) {
                    int byteVal;
                    iss >> byteVal;
                    macAddress[i] = static_cast<uint8_t>(byteVal);
                }

                // Open binary file
                std::ifstream firmwareFile(filePath, std::ios::binary);
                if (!firmwareFile.is_open()) {
                    std::cerr << "[AMDiag] Failed to open firmware file: " << filePath << "\n";
                    continue;
                }

                // Load file contents
                programData.assign(std::istreambuf_iterator<char>(firmwareFile), {});
                firmwareFile.close();

                expectedFileLength = static_cast<int>(programData.size());
                receivedBytesCount = expectedFileLength;
                beginReprogramMessageID = startID;
                messageBytesMessageID = dataID;
                endReprogramMessageID = endID;
                programModeStarted = true;

                std::ostringstream __amdiag_ss;
                __amdiag_ss << "[AMDiag] [START_REPROGRAM] File loaded: "
                            << filePath << ", " << expectedFileLength << " bytes";
                HAL_SendConsoleLine(__amdiag_ss.str().c_str());

                // Send the initial "begin update" CAN message
                int32_t status;
                SendCanMessage(activeBusId, beginReprogramMessageID, macAddress, 6,
                               &status);
                HAL_SendConsoleLine("[AMDiag] Sent begin reprogram command to AM Device");
            }
        }
    }

    HAL_SendConsoleLine("[AMDiag] Cleaning up after disconnect");
}

// Server thread entry point
void ServerThreadMain(uint16_t port) {
    std::ostringstream __amdiag_ss;
    __amdiag_ss << "[AMDiag] Diagnostics server starting on port " << port;
    HAL_SendConsoleLine(__amdiag_ss.str().c_str());
    
    // We assume HAL is already initialized by WPILib.
    if (!wpi::RobotBase::IsReal()) {
        HAL_SendConsoleLine("[AMDiag] Not running on real hardware; server exiting.");
        return;
    }

    int server_fd;
    struct sockaddr_in address {};
    int addrlen = sizeof(address);

    // Create socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == 0) {
        HAL_SendConsoleLine("[AMDiag] Socket creation failed");
        return;
    }

    int opt = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                   &opt, sizeof(opt))) {
        HAL_SendConsoleLine("[AMDiag] setsockopt failed");
        close(server_fd);
        return;
    }

    // Configure server address
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(port);

    // Bind socket to the port
    if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
        HAL_SendConsoleLine("[AMDiag] Bind failed");
        close(server_fd);
        return;
    }

    // Listen for incoming connections
    if (listen(server_fd, 3) < 0) {
        HAL_SendConsoleLine("[AMDiag] Listen failed");
        close(server_fd);
        return;
    }

    HAL_SendConsoleLine("[AMDiag] Waiting for connection...");

    // Accept-loop
    while (true) {
        int new_socket = accept(server_fd,
                                (struct sockaddr*)&address,
                                (socklen_t*)&addrlen);
        if (new_socket < 0) {
            HAL_SendConsoleLine("[AMDiag] Failed to accept connection");
            continue;
        }

        // Spawn a handler thread per connection
        std::thread(HandleConnection, new_socket).detach();
    }

    // Should never get here unless accept loop ends
    close(server_fd);
    HAL_SendConsoleLine("[AMDiag] Server thread exiting");
}

}  // namespace

void EnsureServerRunning(uint16_t port) {
    // Only start once
    std::call_once(g_serverOnce, [port]() {
        g_serverStarted.store(true);
        std::thread(ServerThreadMain, port).detach();
    });
}

#endif  // _WIN32

}  // namespace diag
}  // namespace andymark
