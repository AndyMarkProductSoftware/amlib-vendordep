#include "header.h"

namespace andymark {
void amlib_placeholder() {}
}
