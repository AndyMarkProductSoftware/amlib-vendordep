﻿#pragma once

// Placeholder export so the native library continues to build cleanly
// until real AndyMark sources are copied in from the active C++ dev project.
namespace andymark {
void amlib_placeholder();
}
