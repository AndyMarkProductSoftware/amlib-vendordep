#include "AMCanDevice.h"
#include <algorithm>
#include <cstring>
#include <exception>
#include <iostream>

CanDevice::CanDevice(int busId, int deviceID, int deviceManufacturer, int deviceType)
    : m_can(busId, deviceID, deviceManufacturer, deviceType), m_busId(busId), m_deviceID(deviceID), 
      deviceManufacturer(deviceManufacturer), deviceType(deviceType) {

        //std::cout << "Initialized Device" << std::endl;
    }

void CanDevice::SendCANMessage(int apiID, const uint8_t* data, int length) {
    try
    {
            HAL_CANMessage message{};
            const int payloadLength = data == nullptr ? 0 : std::clamp(length, 0, static_cast<int>(sizeof(message.data)));

            message.dataSize = static_cast<uint8_t>(payloadLength);
            if (payloadLength > 0) {
                std::memcpy(message.data, data, static_cast<size_t>(payloadLength));
            }

            m_can.WritePacket(apiID, message);
    }
    catch(const std::exception&)
    {
        return;
    }
}

bool CanDevice::ReceiveCANMessage(int apiID, HAL_CANReceiveMessage* data,int timeoutMs) {

    return m_can.ReadPacketTimeout(apiID, timeoutMs, data);
       
    }

void CanDevice::RestartDevice(){
    SendCANMessage(RESTART_DEVICE_API,NULL,0);
}
int CanDevice::getDeviceId(){
    return m_deviceID;
}
