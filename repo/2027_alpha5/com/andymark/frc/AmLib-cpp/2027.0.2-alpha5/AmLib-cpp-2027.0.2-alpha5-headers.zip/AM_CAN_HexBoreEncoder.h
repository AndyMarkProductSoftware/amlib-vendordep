/**
 * @file AM_CAN_Encoder.h
 * @brief Absolute magnetic encoder over CAN (AndyMark).
 * @details Consumes encoder telemetry/status frames and exposes simple getters,
 *          plus commands to set/reset the sensor's zero offset and report period.
 *
 * Telemetry frame (API 0x23, 8B, little-endian multi-byte fields):
 *   [0..1] u16 angle_zeroed_counts
 *   [2..3] i16 velocity_counts_per_s
 *   [4..5] u16 magnitude
 *   [6]    u8  diag_err
 *   [7]    u8  seq
 *
 * Status frame (API 0x24, 8B):
 *   [0..1] u16 angle_offset_cd (centi-degrees 0..36000; 36000≡0)
 *   [2]    u8  agc
 *   [3]    u8  diag_misc  (bit0 = LF)
 *   [4..5] u16 raw_angle_comp
 *   [6..7] u16 errfl
 *
 * Command APIs (TX):
 *   0x20 -> SetZeroHere (no payload)
 *   0x21 -> ResetOffset (no payload)
 *   0x22 -> SetOffsetDegrees (payload u16 = centi-degrees, little-endian)
 *   0x1B -> SetReportPeriod (payload u16 = period ms, little-endian)
 *   0x1C -> ResetReportPeriod (no payload)
 *
 * Units/Scaling:
 *   - Counts per rev = 16384
 *   - deg  = counts * (360 / 16384)
 *   - rad  = counts * (2π / 16384)
 *   - deg/s, rad/s computed with same scale from counts/sec
 *
 * © AndyMark. All rights reserved.
 */

#pragma once

#include "AMCanDevice.h"
#include "AMCanDevice_Constants.h"
#include <cstdint>

/** @brief Telemetry snapshot parsed from the fast frame. */
struct AM_EncoderTelemetry {
    uint16_t angle_zeroed_counts;   /**< Position with offset applied (0..16383). */
    int16_t  velocity_counts_per_s; /**< Angular velocity in counts per second (wrap-safe). */
    uint16_t magnitude;             /**< Sensor CORDIC magnitude (health). */
    uint8_t  diag_err;              /**< Packed diag bits: b0=PARERR,b1=INVCOMM,b2=FRERR,b3=MAGL,b4=MAGH,b5=COF. */
    uint8_t  seq;                   /**< Sequence counter (0..255). */
};

/** @brief Status snapshot parsed from the slow frame. */
struct AM_EncoderStatus {
    uint16_t angle_offset_cd;  /**< Offset in centi-degrees (0..36000; 36000≡0). */
    uint8_t  agc;              /**< DIAAGC[7:0]. */
    uint8_t  diag_misc;        /**< Misc diagnostics: bit0=LF. */
    uint16_t raw_angle_comp;   /**< ANGLECOM raw (0..16383), no offset. */
    uint16_t errfl;            /**< Sensor ERRFL snapshot. */
};

/**
 * @class CANEncoder
 * @brief AndyMark absolute magnetic encoder (CAN).
 * @details Uses two receive APIs (telemetry/status) and provides convenience
 *          conversions to degrees/radians, along with commands to zero or set offset.
 */
class AM_CAN_HexBoreEncoder : public CanDevice {
public:
    /**
     * @brief Construct an encoder on a given CAN bus and CAN ID.
     */
    explicit AM_CAN_HexBoreEncoder(int busId, int deviceID);

    /**
     * @name Receive
     * @{
     */
    /**
     * @brief Read the latest telemetry frame (blocking up to timeoutMs).
     * @param timeoutMs Timeout in milliseconds.
     * @return Last known telemetry; if timeout, unchanged fields are returned.
     */
    AM_EncoderTelemetry GetTelemetry(int timeoutMs = 150);

    /**
     * @brief Read the latest status frame (blocking up to timeoutMs).
     * @param timeoutMs Timeout in milliseconds.
     * @return Last known status; if timeout, unchanged fields are returned.
     */
    AM_EncoderStatus GetStatus(int timeoutMs = 150);
    /** @} */

    /**
     * @name Convenience getters (convert counts to user units)
     * @{
     */
    /** @brief Latest angle in degrees from cached telemetry. */
    double GetAngleDegrees() const;
    /** @brief Latest angle in radians from cached telemetry. */
    double GetAngleRadians() const;
    /** @brief Latest angular velocity in deg/s from cached telemetry. */
    double GetVelocityDegPerSec() const;
    /** @brief Latest angular velocity in rad/s from cached telemetry. */
    double GetVelocityRadPerSec() const;
    /** @} */

    /**
     * @name Commands
     * @{
     */
    /** @brief Set zero to the current sensor position (no payload). */
    void SetZeroHere();
    /** @brief Reset zero offset to 0 (no payload). */
    void ResetOffset();
    /**
     * @brief Set zero offset to a specific angle.
     * @param degrees Offset in degrees (two decimals supported; internally sent as centi-degrees).
     */
    void SetOffsetDegrees(double degrees);
    /**
     * @brief Set periodic report period (ms) for device reports.
     * @param periodMs Period in milliseconds.
     */
    void SetReportPeriod(int periodMs);
    /** @brief Reset device report period to default (10ms). */
    void ResetReportPeriod();
    /** @} */

    /** @brief Access the cached last samples (updated by GetTelemetry/GetStatus). */
    const AM_EncoderTelemetry& LastTelemetry() const { return m_telem; }
    const AM_EncoderStatus&    LastStatus()    const { return m_status; }

private:
    static constexpr double kCountsPerRev = 16384.0;

    static inline uint16_t rd_u16le(const uint8_t* p) {
        return static_cast<uint16_t>((p[1] << 8) | p[0]);
    }
    static inline int16_t rd_i16le(const uint8_t* p) {
        return static_cast<int16_t>((p[1] << 8) | p[0]);
    }

    AM_EncoderTelemetry m_telem{};
    AM_EncoderStatus    m_status{};
};
