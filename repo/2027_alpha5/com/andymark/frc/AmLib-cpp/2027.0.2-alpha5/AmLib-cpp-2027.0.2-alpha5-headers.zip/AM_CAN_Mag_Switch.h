/**
 * @file AM_CAN_Mag_Switch.h
 * @brief Hall-effect magnetic switch device over CAN.
 * @details Provides access to magnet detected state and timestamp over CAN.
 *
 * (c) AndyMark. All rights reserved.
 */

#pragma once

#include "AMCanDevice.h"
#include "AMCanDevice_Constants.h"

/**
 * @struct AM_MagSwitchData
 * @brief Aggregated reading from the magnetic switch.
 * @details Includes magnetDetected and a millisecond timestamp.
 */
struct AM_MagSwitchData {
    /** True when magnet is detected. */
    bool magnetDetected;
    /** Milliseconds since device boot for the reading. */
    uint32_t timeStamp;
};

/**
 * @class AM_CAN_Mag_Switch
 * @brief Hall-effect magnetic switch device over CAN.
 */
class AM_CAN_Mag_Switch : public CanDevice {
public:
    /**
     * @brief Construct a CAN magnetic switch with the given CAN bus and CAN ID.
     * @param busId The selected CAN bus number.
     * @param deviceID The device's CAN ID.
     */
    explicit AM_CAN_Mag_Switch(int busId, int deviceID);

    /**
     * @brief Fetch the most recent reading using a default timeout.
     * @return A filled AM_MagSwitchData struct.
     */
    AM_MagSwitchData GetData();

    /**
     * @brief Fetch reading with a custom timeout.
     * @param timeoutMs Timeout in milliseconds for the CAN read.
     * @return A filled AM_MagSwitchData struct.
     */
    AM_MagSwitchData GetData(int timeoutMs);

    /**
     * @brief Request a new periodic report interval from the device.
     * @param periodMs Period in milliseconds.
     * @return True if the request frame was queued.
     */
    bool SetReportPeriod(int periodMs);

    /**
     * @brief Reset the report period to the device default.
     * @return True if the request frame was queued.
     */
    bool ResetReportPeriod();

    /** Persistent data buffer for the most recent reading. */
    AM_MagSwitchData data;

private:
    static uint32_t ParseTimestampLE(const uint8_t* bytes);
};
