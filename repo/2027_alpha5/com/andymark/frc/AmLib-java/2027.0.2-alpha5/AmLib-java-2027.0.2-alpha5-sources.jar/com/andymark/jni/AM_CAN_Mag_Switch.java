package com.andymark.jni;

import org.wpilib.hardware.hal.can.CANReceiveMessage;

/**
 * Hall-effect magnetic switch device over CAN.
 *
 * Reports magnetDetected (boolean) and a millisecond timestamp (int).
 *
 * (c) AndyMark. All rights reserved.
 */
public class AM_CAN_Mag_Switch extends AMCanDevice {

    /**
     * Aggregated reading from the magnetic switch.
     */
    public static class AM_MagSwitchData {
        /** True when magnet is detected. */
        public boolean magnetDetected;

        /** Milliseconds since device boot for the reading (uint32 on wire). */
        public int timeStamp;
    }

    /** Persistent data buffer for the most recent reading. */
    private final AM_MagSwitchData data = new AM_MagSwitchData();

    /**
     * Construct a CAN magnetic switch with the given CAN bus and CAN ID.
     *
     * @param busId the selected CAN bus number
     * @param deviceID the device's CAN ID
     */
    public AM_CAN_Mag_Switch(int busId, int deviceID) {
        super(busId, deviceID, 15, 10); // 15 = AndyMark vendor ID, 10 = Miscellaneous (device type)
    }

    /**
     * Fetch the most recent magnet state using a default timeout.
     *
     * @return a filled {@link AM_MagSwitchData}
     */
    public AM_MagSwitchData getData() {
        return getData(150);
    }

    /**
     * Fetch magnet state with a custom timeout applied to the API frame.
     *
     * @param timeoutMs timeout in milliseconds for the CAN read
     * @return a filled {@link AM_MagSwitchData}
     */
    public AM_MagSwitchData getData(int timeoutMs) {
        CANReceiveMessage hallData = new CANReceiveMessage();

        if (receiveCANMessage(AMCanDevice_Constants.HALL_EFFECT_DATA, hallData, timeoutMs)) {
            byte[] b = hallData.data;

            // b[0] = magnet detected? (1/0)
            data.magnetDetected = (b[0] & 0xFF) != 0;

            // b[1..4] = timestamp (uint32 LE)
            int ts =
                    ((b[4] & 0xFF) << 24) |
                    ((b[3] & 0xFF) << 16) |
                    ((b[2] & 0xFF) << 8)  |
                    ((b[1] & 0xFF));
            data.timeStamp = ts;
        }

        return data;
    }

    /**
     * Request a new periodic report interval from the device.
     *
     * @param periodMs period in milliseconds
     * @return true if the request frame was queued
     */
    public boolean setReportPeriod(int periodMs) {
        int p = Math.max(0, Math.min(0xFFFF, periodMs));
        byte[] bytes = new byte[] {
            (byte)(p & 0xFF),        // LSB
            (byte)((p >>> 8) & 0xFF) // MSB
        };
        sendCANMessage(AMCanDevice_Constants.SET_REPORT_PERIOD_API, bytes);
        return true;
    }

    /**
     * Reset the report period to the device default.
     *
     * @return true if the request frame was queued
     */
    public boolean resetReportPeriod() {
        sendCANMessage(AMCanDevice_Constants.RESET_REPORT_PERIOD_API, new byte[0]);
        return true;
    }
}
