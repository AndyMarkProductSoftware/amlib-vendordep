/**
 * @file AM_CAN_Color_Sensor.h
 * @brief Color sensor device over CAN.
 * @details Provides access to color channels, proximity, and timestamp over CAN.
 *
 * @copyright
 *   (c) AndyMark. All rights reserved.
 */

#pragma once

#include "AMCanDevice.h"
#include "AMCanDevice_Constants.h"

/**
 * @struct ColorSensorData
 * @brief Aggregated readings from the color sensor.
 * @details Includes 16-bit clear/red/green/blue, 8-bit proximity, and a millisecond timestamp.
 */
struct AM_ColorSensorData {
	/** 16-bit color channel values. */
    uint16_t clearC, red, green, blue;
	/** 8-bit proximity metric reported by the sensor. */
    uint8_t  proximity;
	/** Milliseconds since device boot for the reading. */
    uint32_t millisStamp;
};

/**
 * @class CANColorSensor
 * @brief Color/proximity sensor device.
 * @details Retrieves color data across multiple API IDs and supports report period configuration.

 */
class AM_CANColorSensor : public CanDevice {
public:
    /**
 * @brief Construct a CAN color sensor with the given CAN ID.
 * @param deviceID The device's CAN ID.
 */
    explicit AM_CANColorSensor(int deviceID);
	/**
 * @brief Fetch the most recent color/proximity readings using default timeouts.
 * @return A filled ColorSensorData struct.
 */
    AM_ColorSensorData GetData();
	    /**
 * @brief Fetch color/proximity readings with a custom timeout applied to each API frame.
 * @param timeoutMs Timeout in milliseconds for each CAN read.
 * @return A filled ColorSensorData struct.
 */
    AM_ColorSensorData GetData(int timeoutMs);

    AM_ColorSensorData data;
    /**
 * @brief Request a new periodic report interval from the device.
 * @param period Period in milliseconds (device-specific resolution).
 * @return True if the request frame was queued.
 */
    bool SetReportPeriod(int period);
	
	    /**
 * @brief Reset the report period to the device default.
 * @return True if the request frame was queued.
 */
    bool ResetReportPeriod();
    

private:
    double ParseCANData(const frc::CANData* data);

protected:
    
};