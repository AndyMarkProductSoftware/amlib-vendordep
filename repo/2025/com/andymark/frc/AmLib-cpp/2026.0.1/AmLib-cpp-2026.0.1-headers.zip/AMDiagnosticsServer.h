#pragma once

#include <cstdint>

namespace andymark {
namespace diag {

/**
 * Ensure the diagnostics/CAN server is running.
 *
 * Safe to call multiple times; only starts once.
 * Call this from your device base class constructor.
 */
void EnsureServerRunning(uint16_t port = 12345);

// Optional: you could add StopServer() later if you care about explicit shutdown.
// void StopServer();

}  // namespace diag
}  // namespace andymark
