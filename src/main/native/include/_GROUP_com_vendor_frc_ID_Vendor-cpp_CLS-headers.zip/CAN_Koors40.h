#pragma once

#include "AMCanDevice.h"
#include "AMCanDevice_Constants.h"

class CAN_Koors40 : public CanDevice {
public:
    explicit CAN_Koors40(int deviceID);
    
    void setSpeed(int speed);
    void setBrakeMode();
    void setCoastMode();

    uint64_t GetJunkData();

private:

protected:
    
};