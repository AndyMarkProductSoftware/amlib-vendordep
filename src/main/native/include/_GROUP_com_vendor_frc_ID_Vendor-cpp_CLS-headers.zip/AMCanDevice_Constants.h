#pragma once

constexpr int SET_REPORT_PERIOD_API = 0x0B; 
constexpr int RESET_REPORT_PERIOD_API = 0x0C;
constexpr int GET_JUNK_DATA = 0x20;
constexpr int ENCODER_POSITION_API = 0x00; //DO THIS
constexpr int ENCODER_VELOCITY_API = 0x00; //DO THIS
constexpr int RESTART_DEVICE_API = 0x07; //DO THIS

constexpr int MOTOR_CONTROL_SET_SPEED_API = 0x10;
constexpr int MOTOR_CONTROL_SET_BRAKE_COAST_API = 0x11;