#pragma once

#include <frc/CAN.h>
#include "AMCanDevice_Constants.h"
#include <chrono>
#include <thread>

class CanDevice {
public:
    explicit CanDevice(int deviceID, int deviceManufacturer, int deviceType);
    virtual ~CanDevice() = default;
    
    int getDeviceId();
    
    void RestartDevice();
    



protected:
    frc::CAN m_can;
    int m_deviceID;
    int deviceManufacturer;
    int deviceType;

    void SendCANMessage(int apiID, const uint8_t* data, int length);
    bool ReceiveCANMessage(int apiID, frc::CANData*, int timeoutMs);
};
