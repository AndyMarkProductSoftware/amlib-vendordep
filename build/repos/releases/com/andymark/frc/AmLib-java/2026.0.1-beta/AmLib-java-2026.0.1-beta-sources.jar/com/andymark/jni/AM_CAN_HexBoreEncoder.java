/**
 * @file AM_CAN_Encoder.java
 * @brief Absolute magnetic encoder over CAN (AndyMark).
 *
 * <p>Consumes two receive frames and exposes simple getters:
 * <ul>
 *   <li><b>Telemetry</b> (API ENCODER_TELEMETRY_DATA, 0x23): angle, velocity, magnitude, diag, seq</li>
 *   <li><b>Status</b>    (API ENCODER_STATUS_DATA,    0x24): offset, AGC, misc diag, raw angle, ERRFL</li>
 * </ul>
 *
 * <p>Commands this device accepts:
 * <ul>
 *   <li>ENCODER_ZERO_CURRENT_POS (0x20) – set zero here</li>
 *   <li>ENCODER_RESET_OFFSET     (0x21) – clear zero</li>
 *   <li>ENCODER_SET_OFFSET       (0x22) – set offset (centi-degrees)</li>
 *   <li>SET_REPORT_PERIOD_API    (0x0B) – set report period (ms)</li>
 *   <li>RESET_REPORT_PERIOD_API  (0x0C) – restore default period</li>
 * </ul>
 *
 * <p><b>Units & scaling</b>
 * <ul>
 *   <li>Counts per rev = 16384</li>
 *   <li>deg  = counts * (360 / 16384)</li>
 *   <li>rad  = counts * (2π  / 16384)</li>
 *   <li>Velocity: same factors applied to counts/sec</li>
 * </ul>
 *
 * <p>© AndyMark. All rights reserved.</p>
 */

 package com.andymark.jni;

 import edu.wpi.first.hal.CANData;
 import com.andymark.jni.AM_CAN_HexBoreEncoder.AM_EncoderStatus;


 
 public class AM_CAN_HexBoreEncoder extends AMCanDevice {
 
   /** Parsed fast-frame snapshot. */
   public static final class AM_Encoder_Telemetry {
     /** Position with offset applied (0..16383). */
     public int angleZeroedCounts;
     /** Angular velocity in counts/sec (wrap-safe). */
     public short velocityCountsPerSec;
     /** CORDIC magnitude (health). */
     public int magnitude;
     /** Packed diag bits: b0=PARERR,b1=INVCOMM,b2=FRERR,b3=MAGL,b4=MAGH,b5=COF. */
     public byte diagErr;
     /** Sequence counter (0..255). */
     public byte seq;
   }
 
   /** Parsed slow/status snapshot. */
   public static final class AM_EncoderStatus {
     /** Offset in centi-degrees (0..36000; 36000≡0). */
     public int angleOffsetCentiDeg;
     /** DIAAGC[7:0]. */
     public byte agc;
     /** Misc diagnostics: bit0=LF. */
     public byte diagMisc;
     /** ANGLECOM raw (0..16383), no offset. */
     public int rawAngleComp;
     /** Sensor ERRFL snapshot. */
     public int errfl;
   }
 
   // Cached snapshots
   private final AM_Encoder_Telemetry telem = new AM_Encoder_Telemetry();
   private final AM_EncoderStatus status = new AM_EncoderStatus();
 
   // Scale constants
   private static final double COUNTS_PER_REV = 16384.0;
   private static final double DEG_PER_COUNT  = 360.0 / COUNTS_PER_REV;
   private static final double RAD_PER_COUNT  = (2.0 * Math.PI) / COUNTS_PER_REV;
 
   /**
    * Create an encoder device on a given CAN ID.
    *
    * @param deviceId the device's CAN ID on the bus
    */
   public AM_CAN_HexBoreEncoder(int deviceId) {
     super(deviceId, 15, 7);
   }
 

 
   // ----------------------------- Receive/parsing -----------------------------
 
   /**
    * Refresh & return the latest telemetry snapshot.
    *
    * <p>Frame layout (8 bytes, little-endian multi-byte fields):
    * <pre>
    * [0..1] u16 angle_zeroed_counts
    * [2..3] i16 velocity_counts_per_s
    * [4..5] u16 magnitude
    * [6]    u8  diag_err
    * [7]    u8  seq
    * </pre>
    *
    * @param timeoutMs timeout for receive
    * @return cached {@link Telemetry} (updated if a frame arrived)
    */
   public AM_Encoder_Telemetry getTelemetry(int timeoutMs) {
     CANData d = new CANData();
     if (receiveCANMessage(AMCanDevice_Constants.ENCODER_TELEMETRY_DATA, d, timeoutMs) && d.length >= 8) {
       telem.angleZeroedCounts   = rdU16LE(d.data, 0);
       telem.velocityCountsPerSec= rdI16LE(d.data, 2);
       telem.magnitude           = rdU16LE(d.data, 4);
       telem.diagErr             = d.data[6];
       telem.seq                 = d.data[7];
     }
     return telem;
   }
 
   /** Overload with a default timeout. */
   public AM_Encoder_Telemetry getTelemetry() { return getTelemetry(150); }
 
   /**
    * Refresh & return the latest status snapshot.
    *
    * <p>Frame layout (8 bytes, little-endian multi-byte fields):
    * <pre>
    * [0..1] u16 angle_offset_cd
    * [2]    u8  agc
    * [3]    u8  diag_misc
    * [4..5] u16 raw_angle_comp
    * [6..7] u16 errfl
    * </pre>
    *
    * @param timeoutMs timeout for receive
    * @return cached {@link Status} (updated if a frame arrived)
    */
   public AM_EncoderStatus getStatus(int timeoutMs) {
     CANData d = new CANData();
     if (receiveCANMessage(AMCanDevice_Constants.ENCODER_STATUS_DATA, d, timeoutMs) && d.length >= 8) {
       status.angleOffsetCentiDeg = rdU16LE(d.data, 0);
       status.agc                 = d.data[2];
       status.diagMisc            = d.data[3];
       status.rawAngleComp        = rdU16LE(d.data, 4);
       status.errfl               = rdU16LE(d.data, 6);
     }
     return status;
   }
 
   /** Overload with a default timeout. */
   public AM_EncoderStatus getStatus() { return getStatus(150); }
 
   // --------------------------- Convenience getters ---------------------------
 
   /** @return latest angle (degrees) from cached telemetry. */
   public double getAngleDegrees() {
     return (telem.angleZeroedCounts & 0x3FFF) * DEG_PER_COUNT;
   }
 
   /** @return latest angle (radians) from cached telemetry. */
   public double getAngleRadians() {
     return getAngleDegrees() * (Math.PI / 180.0);
   }
 
   /** @return latest angular velocity (deg/s) from cached telemetry. */
   public double getVelocityDegPerSec() {
     return telem.velocityCountsPerSec * DEG_PER_COUNT;
   }
 
   /** @return latest angular velocity (rad/s) from cached telemetry. */
   public double getVelocityRadPerSec() {
     return telem.velocityCountsPerSec * RAD_PER_COUNT;
   }
 
   /** @return immutable view of the last telemetry. */
   public AM_Encoder_Telemetry lastTelemetry() { return telem; }
 
   /** @return immutable view of the last status. */
   public AM_EncoderStatus lastStatus() { return status; }
 
   // -------------------------------- Commands ---------------------------------
 
   /** Send "set zero to current position" (no payload). */
   public void setZeroHere() {
     sendCANMessage(AMCanDevice_Constants.ENCODER_ZERO_CURRENT_POS, null);
   }
 
   /** Send "reset offset to 0" (no payload). */
   public void resetOffset() {
     sendCANMessage(AMCanDevice_Constants.ENCODER_RESET_OFFSET, null);
   }
 
   /**
    * Send "set offset to specific angle" (two decimals).
    *
    * @param degrees offset in degrees; will be normalized to [0, 360)
    */
   public void setOffsetDegrees(double degrees) {
     int cd = (int)Math.round(degrees * 100.0);  // centi-degrees
     cd %= 36000; if (cd < 0) cd += 36000;
     if (cd == 36000) cd = 0;
     byte[] payload = new byte[] {
       (byte)(cd & 0xFF),
       (byte)((cd >>> 8) & 0xFF)
     };
     sendCANMessage(AMCanDevice_Constants.ENCODER_SET_OFFSET, payload);
   }
 
   /** Set the device's report period (ms) for periodic messages. */
   public void setReportPeriod(int periodMs) {
     int p = Math.max(0, Math.min(0xFFFF, periodMs));
     byte[] payload = new byte[] {
       (byte)(p & 0xFF),
       (byte)((p >>> 8) & 0xFF)
     };
     sendCANMessage(AMCanDevice_Constants.SET_REPORT_PERIOD_API, payload);
   }
 
   /** Reset report period to the device default. */
   public void resetReportPeriod() {
     sendCANMessage(AMCanDevice_Constants.RESET_REPORT_PERIOD_API, null);
   }
 
   // ------------------------------- Utilities ---------------------------------
 
   private static int rdU16LE(byte[] a, int off) {
     return ((a[off + 1] & 0xFF) << 8) | (a[off] & 0xFF);
   }
 
   private static short rdI16LE(byte[] a, int off) {
     return (short) rdU16LE(a, off);
   }
 }
 